//
//  TouchView.h
//  MirroCamFx
//
//  Created by Vijaya kumar reddy Doddavala on 10/30/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol touchDetectProtocol <NSObject>
@optional
-(void)touchDetected:(UITouch*)t;
@end

@interface TouchDetectView : UIView

@property(nonatomic,assign)id<touchDetectProtocol> touchdelegate;
@end
