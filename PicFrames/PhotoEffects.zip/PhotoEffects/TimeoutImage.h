//
//  TimeoutView.h
//  MirroFx
//
//  Created by Vijaya kumar reddy Doddavala on 10/19/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface TimeoutImage : UIImageView

@property(nonatomic,readwrite)float timeout;
@property(nonatomic,readwrite)float cornerRadius;
@property(nonatomic,retain)UIColor *sColor;
@property(nonatomic,readwrite)float sOpacity;
@property(nonatomic,readwrite)float sRadius;
@property(nonatomic,readwrite)CGSize sOffset;

-(void)start;
-(void)showInView:(UIView*)view;
@end
