//
//  goalBasedOfferWall.h
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/3/12.
//
//

#import <UIKit/UIKit.h>

@interface goalBasedOfferWall : UIView

@end
