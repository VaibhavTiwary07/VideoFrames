//
//  efScrollView.m
//  SimplePhotoFilter
//
//  Created by Vijaya kumar reddy Doddavala on 9/20/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import "efScrollView.h"

@interface efScrollView()
{
    int _groupCount;
}
@end
@implementation efScrollView

@synthesize efs_delegate;
@synthesize efs_Group_delegate;

-(void)registerForNotifications
{
    /* Send the notification saying that group is ready to expand */
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(handleTheNotification:) name:notification_rearrangeTheGroups object:nil];
    
    /* Send the notification saying that group is ready to expand */
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(handleTheNotification:) name:notification_requestForTheExpansion object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(handleTheNotification:) name:notification_ExpandedGroup object:nil];
}

-(void)unregisterForNotifications
{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_rearrangeTheGroups object:nil];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_requestForTheExpansion object:nil];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_ExpandedGroup object:nil];
}

- (id)initWithFrame:(CGRect)frame efInfo:(NSDictionary*)efInfo
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        // Initialization code
        [self registerForNotifications];
        
        self.efs_delegate = nil;
        self.efs_Group_delegate = nil;

        /* Add groups one by one */
        NSArray *groups = [efInfo objectForKey:key_efsGroups];
        if(nil == groups)
        {
            return self;
        }
        
        _groupCount = [groups count];
        int index = 0;
        
        float x = horizantalGapBetweenGroups;
        float y = verticalGapBetweenGroups;
        float width  = frame.size.height - (2*y);
        float height = frame.size.height - (2*y);
        for(index = 0; index < _groupCount; index++)
        {
            CGRect rect = CGRectMake(x, y, width, height);
            efsGroup *grp = [[efsGroup alloc]initWithFrame:rect groupInfo:[groups objectAtIndex:index]];
            grp.userInteractionEnabled = YES;
            //grp.backgroundColor = [UIColor redColor];
            grp.tag = index + efs_grouptag_index;
            [self addSubview:grp];
            [grp release];
            x = x + horizantalGapBetweenGroups + width;
        }
        
        self.contentSize = CGSizeMake(x-horizantalGapBetweenGroups-width, self.frame.size.height);
        //NSLog(@"Initial content size %f,%f",self.contentSize.width,self.contentSize.height);

    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        // Initialization code
        [self registerForNotifications];
        
        self.efs_delegate = nil;
        self.efs_Group_delegate = nil;
    }
    return self;
}

-(void)start
{
    if(nil == self.efs_delegate)
    {
        NSLog(@"Start Failed: efs_delegate is not initialized");
        return;
    }
    
    if(nil == self.efs_Group_delegate)
    {
        NSLog(@"Start Failed: efs_Group_delegate is not initialized");
        return;
    }
    
    _groupCount = [self.efs_delegate numberOfGroupsSupported];
    int index = 0;
    
    float x = horizantalGapBetweenGroups;
    float y = verticalGapBetweenGroups;
    float width  = self.frame.size.height - (2*y);
    float height = self.frame.size.height - (2*y);
    
    for(int index = 0; index < _groupCount; index++)
    {
        CGRect rect = CGRectMake(x, y, width, height);
        efsGroup *grp = [[efsGroup alloc]initWithFrame:rect];
        grp.efs_Group_delegate = self.efs_Group_delegate;
        grp.userInteractionEnabled = YES;
        //grp.backgroundColor = [UIColor redColor];
        grp.tag = index + efs_grouptag_index;
        [self addSubview:grp];
        [grp release];
        x = x + horizantalGapBetweenGroups + width;
    }
    
    //self.contentSize = CGSizeMake(x-horizantalGapBetweenGroups-width, self.frame.size.height);
    self.contentSize = CGSizeMake(x, self.frame.size.height);
    //NSLog(@"Initial content size %f,%f",self.contentSize.width,self.contentSize.height);
    
    for(index = 0; index < _groupCount;index++)
    {
        efsGroup *grp = (efsGroup*)[self viewWithTag:index+efs_grouptag_index];
        grp.center = CGPointMake(x+(self.frame.size.height), grp.center.y);
    }
    
    [UIView animateWithDuration:0.8f animations:^{
        float x = horizantalGapBetweenGroups;
        float y = verticalGapBetweenGroups;
        float width  = self.frame.size.height - (2*y);
        float height = self.frame.size.height - (2*y);
        for(int index = 0; index < _groupCount;index++)
        {
            CGRect rect = CGRectMake(x, y, width, height);
            efsGroup *grp = (efsGroup*)[self viewWithTag:index+efs_grouptag_index];
            grp.center = CGPointMake(rect.origin.x+(rect.size.width/2.0), grp.center.y);
            x = x + horizantalGapBetweenGroups + width;
            [grp setMainLabelTextTo:[self.efs_delegate getNameOfTheGroup:index]];
        }
        
    }];
}

-(void)sendReadyToExpand
{
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_readyForExpansion object:self];
}

-(void)handleTheNotification:(NSNotification*)notification
{
    if([notification.name isEqualToString:notification_rearrangeTheGroups])
    {
        //efsGroup *g = (efsGroup*)notification.object;
        //NSLog(@"Received event from tag %d",g.tag);
        int index = 0;
        float x = horizantalGapBetweenGroups;
        float y = verticalGapBetweenGroups;
        float width  = self.frame.size.height - (2*y);
        float height = self.frame.size.height - (2*y);
        for(index = 0; index < _groupCount; index++)
        {
            efsGroup *grp = (efsGroup*)[self viewWithTag:(index+efs_grouptag_index)];
            grp.frame = CGRectMake(x, y, width, height);
            x = x + horizantalGapBetweenGroups + width;
        }
        
        
        
        self.contentSize = CGSizeMake(x-horizantalGapBetweenGroups-width, self.frame.size.height);
        
        
        //NSLog(@"rearranged content size %f,%f",self.contentSize.width,self.contentSize.height);
    }
    else if([notification.name isEqualToString:notification_requestForTheExpansion])
    {
        efsGroup *grp = (efsGroup*)notification.object;
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.5];
        
        self.contentOffset = CGPointMake(grp.frame.origin.x, 0);
        
        [UIView commitAnimations];
        
        [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(sendReadyToExpand) userInfo:nil repeats:NO];
    }
    else if([notification.name isEqualToString:notification_ExpandedGroup])
    {
        int index = 0;
        efsGroup *grp;
        float x = horizantalGapBetweenGroups;
        float y = verticalGapBetweenGroups;
        for(index = 0; index < _groupCount; index++)
        {
            grp = (efsGroup*)[self viewWithTag:(index+efs_grouptag_index)];
            grp.frame = CGRectMake(x, y, grp.frame.size.width, grp.frame.size.height);
            x = x + horizantalGapBetweenGroups + grp.frame.size.width;
        }
        
        
        //self.contentSize = CGSizeMake(x-horizantalGapBetweenGroups-grp.frame.size.width, self.frame.size.height);
        self.contentSize = CGSizeMake(x, self.frame.size.height);
        //[UIView commitAnimations];
        //NSLog(@"expanded content size %f,%f",self.contentSize.width,self.contentSize.height);
    }
}

-(void)dealloc
{
    [self unregisterForNotifications];
    
    [super dealloc];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
