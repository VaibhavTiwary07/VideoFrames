//
//  efsGroup.h
//  SimplePhotoFilter
//
//  Created by Vijaya kumar reddy Doddavala on 9/20/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "efspub.h"
#import "efsPriv.h"
#import <QuartzCore/QuartzCore.h>



typedef enum
{
    GROUP_IDLE,
    GROUP_EXPAND_INPROGRESS,
    GROUP_EXPANDED,
    GROUP_INVALID
}eGroupState;



@interface efsGroup : UIImageView
{
    id<efsGroupDelegate>	efs_Group_delegate;
}

@property(nonatomic,retain)id<efsGroupDelegate>	efs_Group_delegate;
- (id)initWithFrame:(CGRect)frame groupInfo:(NSDictionary*)groupInfo;
- (id)initWithFrame:(CGRect)frame;
-(void)setMainLabelTextTo:(NSString*)str;
@end
