//
//  efspub.h
//  SimplePhotoFilter
//
//  Created by Vijaya kumar reddy Doddavala on 10/16/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#ifndef SimplePhotoFilter_efspub_h
#define SimplePhotoFilter_efspub_h


//efs keys, applicable for entire efs
#define key_efsImageInput        @"efsImageInput"
#define key_efsGapBetweenFilters @"efsFilterGap"
#define key_efsGroups            @"efsGroups"

//group keys applicable for only groups
#define key_GroupId              @"groupId"
#define key_GroupName            @"groupName"
#define key_GroupImageName       @"groupImageName"
#define key_GroupFilterCount     @"groupFilterCount"

#define notification_updateGroupImages @"updateGroupExpansion"

@protocol efsDelegate
- (int)numberOfGroupsSupported;
- (NSString*)getNameOfTheGroup:(int)grpId;
@optional
- (float)groupWidthAndHeight;
@end

@protocol efsGroupDelegate
- (int)filterCountFor:(NSInteger)groupId;
- (UIImage*)filterImageForGroup:(NSInteger)groupId atIndex:(NSInteger)index;
- (NSString*)nameOfTheFilterInGroup:(NSInteger)grpId atIndex:(NSInteger)index;
- (void)filterDidSelectedInGroup:(NSInteger)grpId atIndex:(NSInteger)index;
- (void)groupExpandedWithId:(int)grpId;
-(BOOL)isContentLockedOfGrpId:(int)grpId atIndex:(int)index;
-(UIImage*)getImageForGroup:(int)index;
@end

@protocol hesDelegate
-(int)numberOfItems;
-(NSString*)nameOfTheItemAtIndex:(int)index;
-(UIImage*)imageForTheItemAtIndex:(int)index;
-(void)itemDidSelectedAtIndex:(int)index;
-(BOOL)isItemLockedAtIndex:(int)index;
-(void)hesScrollViewWillExit:(id)sender;
@end

#endif
