//
//  efScrollView.h
//  SimplePhotoFilter
//
//  Created by Vijaya kumar reddy Doddavala on 9/20/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "efspub.h"
#import "efsPriv.h"
#import "efsGroup.h"

// Dictionary Keys, which are pased as the input to efs

#define horizantalGapBetweenGroups         5.0
#define verticalGapBetweenGroups           5.0


@interface efScrollView : UIScrollView
{
    id<efsDelegate>	efs_delegate;
    id<efsGroupDelegate>	efs_Group_delegate;
}

@property(nonatomic,retain)id<efsDelegate>	efs_delegate;
@property(nonatomic,retain)id<efsGroupDelegate>	efs_Group_delegate;

-(void)start;
- (id)initWithFrame:(CGRect)frame efInfo:(NSDictionary*)efInfo;
@end
