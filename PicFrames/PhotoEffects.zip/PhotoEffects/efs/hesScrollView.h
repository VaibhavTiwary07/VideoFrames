//
//  HeScrollView.h
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 11/24/12.
//
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "efsPriv.h"
#import "efspub.h"
#import "TouchView.h"
@interface hesScrollView : UIView <touchDetectProtocol>

@property(nonatomic,retain)id <hesDelegate> hesldelegate;
-(void)showItems;
@end
