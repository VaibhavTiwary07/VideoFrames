//
//  efsGroup.m
//  SimplePhotoFilter
//
//  Created by Vijaya kumar reddy Doddavala on 9/20/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import "efsGroup.h"

@interface efsGroup()
{
    eGroupState eState;
    NSString    *_grpName;
    NSInteger   _filterCount;
    NSInteger    _grpId;
    UILabel     *_mainLabel;
    UILabel     *_subLabel;
    UIImageView *_headImage;
}
@end

@implementation efsGroup

@synthesize efs_Group_delegate;

- (id)initWithFrame:(CGRect)frame groupInfo:(NSDictionary*)groupInfo
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        // Initialization code
        eState = GROUP_IDLE;
        
        _grpName = [groupInfo objectForKey:key_GroupName];
        _filterCount = [[groupInfo objectForKey:key_GroupFilterCount]integerValue];
        _grpId = [[groupInfo objectForKey:key_GroupId]integerValue];
        
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, 20)];
        lbl.text = [NSString stringWithFormat:@"%f",frame.origin.x];
        lbl.textColor = [UIColor blackColor];
        lbl.textAlignment = UITextAlignmentCenter;
        [self addSubview:lbl];
        [lbl release];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        // Initialization code
        eState = GROUP_IDLE;
#if 0
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, 20)];
        lbl.text = [NSString stringWithFormat:@"%f",frame.origin.x];
        lbl.textColor = [UIColor blackColor];
        lbl.textAlignment = UITextAlignmentCenter;
        [self addSubview:lbl];
        [lbl release];
#endif
        //self.image = [UIImage imageNamed:@"showcase-grunge.png"];
        //UIImageView *border = [[UIImageView alloc]initWithFrame:frame];
        
        //self.layer.borderColor = [UIColor whiteColor].CGColor;
        //self.layer.borderWidth = 3.0;
        //self.backgroundColor = [UIColor clearColor];
        
        
        //[self addSubview:border];
        //[border release];
    }
    
    return self;
}

-(void)setMainLabelTextTo:(NSString*)str
{
    _headImage = [[UIImageView alloc]initWithFrame:CGRectMake(0,0,self.frame.size.width,self.frame.size.height)];
    _headImage.contentMode = UIViewContentModeScaleAspectFit;
    _headImage.image = [self.efs_Group_delegate getImageForGroup:self.tag-efs_grouptag_index];
    _headImage.tag = efs_group_label_tag+4;
    
    [self addSubview:_headImage];
    [_headImage release];
    
    _mainLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,0,self.frame.size.width,self.frame.size.height)];
    _mainLabel.tag = efs_group_label_tag;
    _mainLabel.backgroundColor = [UIColor clearColor];
    //_mainLabel.textColor = [UIColor whiteColor];
    
    _mainLabel.font = [UIFont fontWithName:@"FontleroyBrown" size:40.0];
    _mainLabel.text = str;
    _mainLabel.textAlignment = UITextAlignmentCenter;
    //_mainLabel.
    //_mainLabel.center = CGPointMake(self.center.x, self.center.y);
    self.autoresizesSubviews = NO;
    [self addSubview:_mainLabel];
    [_mainLabel release];
    
    _subLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,self.frame.size.height/2.0,self.frame.size.width,self.frame.size.height/2.0 - 10.0)];
    _subLabel.tag = efs_group_sublabel_tag;
    _subLabel.text = @"-PACK-";
    _subLabel.font = [UIFont fontWithName:@"SourceCodePro-Semibold" size:10.0];
    //_subLabel.textColor = [UIColor whiteColor];
    _subLabel.backgroundColor = [UIColor clearColor];
    _subLabel.textAlignment = UITextAlignmentCenter;
    //_subLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:_subLabel];
    [_subLabel release];
    _mainLabel.hidden = YES;
    _subLabel.hidden = YES;
    
    
    //self.image = [self.efs_Group_delegate getImageForGroup:self.tag-efs_grouptag_index];
}

#if 1

-(void)filterSelected:(id)sender
{
    UIButton *filter = sender;
    
    [self.efs_Group_delegate filterDidSelectedInGroup:_grpId atIndex:filter.tag];
    
    NSLog(@"Filter Selected");
}

-(void)collapseTheGroup:(NSNotification*)notification
{
    /* object that is already expanded only receive
     this event */
    if(eState != GROUP_EXPANDED)
    {
        return;
    }
    
    //NSLog(@"Collapsing the group");
    
    //self.backgroundColor = [UIColor redColor];
    
    /* clear the resources */
    UIView *filterBar = [self viewWithTag:efs_filterbar_tag];
    if(nil != filterBar)
    {
        [filterBar removeFromSuperview];
        filterBar = nil;
    }
    
    /* collapse the group */
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.height, self.frame.size.height);
    
    /* remove the observer, we no longer need to receive expand notifications */
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_collapseOtherGroups object:nil];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_updateGroupImages object:nil];
    
    eState = GROUP_IDLE;
}

-(void)updateTheImages:(NSNotification*)notification
{
    /* object that is already expanded only receive
     this event */
    if(eState != GROUP_EXPANDED)
    {
        return;
    }
    
    for(int index = 0; index < _filterCount; index++)
    {
        UIButton *filter = (UIButton*)[self viewWithTag:index];
        UIImage *filteredImage = [self.efs_Group_delegate filterImageForGroup:_grpId atIndex:index];
        [filter setBackgroundImage:filteredImage forState:UIControlStateNormal];
        
        if([self.efs_Group_delegate isContentLockedOfGrpId:_grpId atIndex:index])
        {
            [filter setImage:[UIImage imageNamed:@"lock.png"] forState:UIControlStateNormal];
        }
        else
        {
            [filter setImage:nil forState:UIControlStateNormal];
        }
    }
}

-(void)expandTheGroup:(NSNotification*)notification
{
    /* object that is already expanded or idle should never receive
       this event */
    if(eState != GROUP_EXPAND_INPROGRESS)
    {
        return;
    }
    
    //NSLog(@"Expandin the group");
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    /* First get the filter count */
    _grpId       = self.tag - efs_grouptag_index;
    _filterCount = [self.efs_Group_delegate filterCountFor:_grpId];
    
    /* We need to add self.frame.size.width to initial x to show the group image even
     after expanging the image */
    float x = efs_gap_between_filters;
    float y = efs_gap_between_filters;
    float width = self.frame.size.height -(2*y);
    float height = self.frame.size.height - (2*y);
    float gap = self.frame.size.height-(2*y)+y;
    
    /* Allocate the view to hold all the filters, also make sure that its background color is
       white */
    UIView *filterBar = [[UIView alloc]initWithFrame:CGRectMake(self.frame.size.width-12.0, 0, self.frame.size.width, self.frame.size.height)];
    filterBar.tag = efs_filterbar_tag;
    filterBar.backgroundColor = [UIColor whiteColor];
    
    /* Now get the image one by one and add to the group */
    for(int index = 0; index < _filterCount; index++)
    {
        /* Allocate the filter and initialize it with its filter number */
        UIButton *filter = [[UIButton alloc]initWithFrame:CGRectMake(x,y, width, height)];
        filter.tag       = index;
        /*
        UILabel *name = [[UILabel alloc]initWithFrame:CGRectMake(11, height-32, width-22, 15)];
        name.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        name.text = [sampleImage textureNameForType:index-1];
        name.textColor = [UIColor whiteColor];
        name.font = [UIFont boldSystemFontOfSize:10.0];
        name.textAlignment = UITextAlignmentCenter;
        [filter addSubview:name];
        [name release];
         */
        
        UILabel *name = [[UILabel alloc]initWithFrame:CGRectMake(0, height-15, width, 15)];
        name.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        name.text = [self.efs_Group_delegate nameOfTheFilterInGroup:_grpId atIndex:index];
        name.textColor = [UIColor whiteColor];
        name.font = [UIFont boldSystemFontOfSize:10.0];
        name.textAlignment = UITextAlignmentCenter;
        [filter addSubview:name];
        [name release];
        
        /* Add the action for the filter button */
        [filter addTarget:self  action:@selector(filterSelected:)  forControlEvents:UIControlEventTouchDown];
        
        /* Assign the image to filter button */
        UIImage *filteredImage = [self.efs_Group_delegate filterImageForGroup:_grpId atIndex:index];
        [filter setBackgroundImage:filteredImage forState:UIControlStateNormal];
        
        if([self.efs_Group_delegate isContentLockedOfGrpId:_grpId atIndex:index])
        {
            [filter setImage:[UIImage imageNamed:@"lock.png"] forState:UIControlStateNormal];
        }
        
        /* Add the filter to filter bar */
        [filterBar addSubview:filter];
        [filter release];
        
        x = x + gap;
        
    }
    
    UIImageView *papers = [[UIImageView alloc]initWithFrame:CGRectMake(x, 0, 12.0, self.frame.size.height)];
    papers.contentMode = UIViewContentModeScaleToFill;
    papers.image = [UIImage imageNamed:@"papers.png"];
    [filterBar addSubview:papers];
    papers.tag = 9999;
    [papers release];
    //x = x + papers.frame.size.width;
    
    /* update filter bar size */
    filterBar.frame = CGRectMake(filterBar.frame.origin.x, filterBar.frame.origin.y, x, filterBar.frame.size.height);
    
    /* Now add the filter bar */
    [self addSubview:filterBar];
    [filterBar release];
    
    /* Expand the group */
    //self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width+x, self.frame.size.height);
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width+x, self.frame.size.height);
    
    [UIView commitAnimations];
    
    /* Change the state to expanded */
    eState = GROUP_EXPANDED;
    [self.efs_Group_delegate groupExpandedWithId:_grpId];
    //self.backgroundColor = [UIColor whiteColor];
    
    /* remove the observer, we no longer need to receive expand notifications */
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_readyForExpansion object:nil];
    
    /* send notification saying that expansion is done */
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_ExpandedGroup object:self];
    
    /* Now subscribe for collapse notifications, if some one else is about to expand then
       we need to collapse */
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(collapseTheGroup:) name:notification_collapseOtherGroups object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updateTheImages:) name:notification_updateGroupImages object:nil];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    if(touch.tapCount == 1)
    {
        /* Expand only when in idle */
        if(eState == GROUP_IDLE)
        {
            /* Change the status to progress */
            eState = GROUP_EXPAND_INPROGRESS;
            
            /* Register for ready to expand notification */
            [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(expandTheGroup:) name:notification_readyForExpansion object:nil];
            
            /* Send the notification saying that group is ready to expand */
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_collapseOtherGroups object:self];
            
            /* Send the notification saying that group is ready to expand */
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_rearrangeTheGroups object:self];
            
            /* Send the notification saying that group is ready to expand */
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_requestForTheExpansion object:self];
        }
    }
}

#else
-(void)collapseTheGroup:(NSNotification*)notification
{
    /* object that is already expanded only receive
     this event */
    if(eState != GROUP_EXPANDED)
    {
        return;
    }
    
    //NSLog(@"Collapsing the group");
    
    self.backgroundColor = [UIColor redColor];
    
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.height, self.frame.size.height);
    
    /* remove the observer, we no longer need to receive expand notifications */
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_collapseOtherGroups object:nil];
    
    eState = GROUP_IDLE;
}

-(void)expandTheGroup:(NSNotification*)notification
{
    /* object that is already expanded or idle should never receive
     this event */
    if(eState != GROUP_EXPAND_INPROGRESS)
    {
        return;
    }
    
    //NSLog(@"Expandin the group");
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    /* Expand the group */
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, 600.0, self.frame.size.height);
    [UIView commitAnimations];
    
    /* Change the state to expanded */
    eState = GROUP_EXPANDED;
    
    //self.backgroundColor = [UIColor whiteColor];
    
    /* remove the observer, we no longer need to receive expand notifications */
    [[NSNotificationCenter defaultCenter]removeObserver:self name:notification_readyForExpansion object:nil];
    
    /* send notification saying that expansion is done */
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_ExpandedGroup object:self];
    
    /* Now subscribe for collapse notifications, if some one else is about to expand then
     we need to collapse */
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(collapseTheGroup:) name:notification_collapseOtherGroups object:nil];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    if(touch.tapCount == 1)
    {
        /* Expand only when in idle */
        if(eState == GROUP_IDLE)
        {
            /* Change the status to progress */
            eState = GROUP_EXPAND_INPROGRESS;
            
            /* Register for ready to expand notification */
            [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(expandTheGroup:) name:notification_readyForExpansion object:nil];
            
            /* Send the notification saying that group is ready to expand */
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_collapseOtherGroups object:self];
            
            /* Send the notification saying that group is ready to expand */
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_rearrangeTheGroups object:self];
            
            /* Send the notification saying that group is ready to expand */
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_requestForTheExpansion object:self];
        }
    }
}

#endif
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
