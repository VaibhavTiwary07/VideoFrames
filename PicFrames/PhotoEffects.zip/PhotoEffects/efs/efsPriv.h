//
//  efsPriv.h
//  SimplePhotoFilter
//
//  Created by Vijaya kumar reddy Doddavala on 9/20/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#ifndef _efsPriv_h
#define _efsPriv_h

//notifications in response to group notifications
#define notification_readyForExpansion @"readyForExpansion"

#define notification_collapseOtherGroups     @"collapseOtherGroups"
#define notification_aboutToExpandGroup      @"aboutToExpandGroup"
#define notification_ExpandedGroup           @"expandedGroup"
#define notification_rearrangeTheGroups      @"rearrangeTheGroups"
#define notification_requestForTheExpansion  @"requestForTheExpansion"

#define efs_grouptag_index                   (1000)
#define efs_filterbar_tag       (3000)
#define efs_gap_between_filters (3.0)
#define efs_group_label_tag     (4658)
#define efs_group_sublabel_tag     (4659)

#define hes_tag_bar               (4660)

#define hes_closebutton_height 40.0
#define hes_scrollbar_size ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ?150.0f : 100.0f)
#define hes_effectBarSize hes_scrollbar_size
#define hes_border_size 3.0

#define hes_GradientBottomColor ([UIColor colorWithRed:0.98f green:0.98f blue:0.98f alpha:1.0])
#define hes_GradientTopColor ([UIColor colorWithRed:1.f green:1.f blue:1.f alpha:1.0])
#define hes_full_screen      ([[UIScreen mainScreen]bounds])
#define hes_frame_widthtoheight_ratio (6.0f/8.0f)
#define hes_font_size    ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ? 14.0f : 10.0f)
#define hes_scrollbar_width (280.0)
#endif
