//
//  HeScrollView.m
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 11/24/12.
//
//

#import "hesScrollView.h"
#import "TouchView.h"

@interface hesScrollView()
{
    CGRect actualFrame;
}
@end
@implementation hesScrollView

@synthesize hesldelegate;

- (id)initWithFrame:(CGRect)frame
{
    CGRect full = [[UIScreen mainScreen]bounds];
    
    //self = [super initWithFrame:frame];
    self = [super initWithFrame:full];
    if (self)
    {
        actualFrame = frame;
        self.userInteractionEnabled = YES;
        //self.backgroundColor = [UIColor greenColor];
        // Initialization code
        TouchDetectView *tdv = [[TouchDetectView alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
        tdv.backgroundColor = [UIColor clearColor];
        tdv.alpha = 0.7;
        tdv.userInteractionEnabled = YES;
        tdv.touchdelegate = self;
        [self addSubview:tdv];
        [tdv release];
        
    }
    
    return self;
}

-(void)touchDetected:(UITouch *)t
{
    [self collapseAnyFramesScrollBars:nil];
}

-(void)addFrameForBar:(UIView*)filterBar withCloseAction:(SEL)action
{
    UIView *shadow = [[UIView alloc]initWithFrame:CGRectMake(0, 0, hes_closebutton_height,filterBar.frame.size.height)];
    shadow.backgroundColor = [UIColor whiteColor];
    shadow.layer.shadowColor = [UIColor blackColor].CGColor;
    shadow.layer.shadowOffset = CGSizeMake(0, 2.0);
    shadow.layer.shadowOpacity = 0.8;
    shadow.layer.shadowRadius = 5.0;
    
    [filterBar addSubview:shadow];
    [shadow release];
    
    UIView *shadowFrame = [[UIView alloc]initWithFrame:CGRectMake(hes_closebutton_height,0, actualFrame.size.width-hes_closebutton_height,actualFrame.size.height)];
    shadowFrame.backgroundColor = [UIColor clearColor];
    shadowFrame.layer.borderColor = [UIColor whiteColor].CGColor;
    shadowFrame.layer.borderWidth = hes_border_size;
    shadowFrame.layer.shadowColor = [UIColor blackColor].CGColor;
    shadowFrame.layer.shadowOffset = CGSizeMake(0.0, 0.0);
    shadowFrame.layer.shadowOpacity = 0.8;
    shadowFrame.layer.shadowRadius = 5.0;
    shadowFrame.layer.masksToBounds = YES;
    shadowFrame.userInteractionEnabled = NO;
    [filterBar addSubview:shadowFrame];
    [shadowFrame release];
    
    UIButton *close = [UIButton buttonWithType:UIButtonTypeCustom];
    close.frame = CGRectMake(0,0,hes_closebutton_height,actualFrame.size.height);
    [close addTarget:self action:action forControlEvents:UIControlEventTouchDown];
    [close setImage:[UIImage imageNamed:@"close.png"] forState:UIControlStateNormal];
    [filterBar addSubview:close];
}

-(void)applyFrame:(id)sender
{
    UIButton *btn = (UIButton*)sender;
    [self.hesldelegate itemDidSelectedAtIndex:btn.tag];
}

-(void)showItems
{
    UIView *v = [self viewWithTag:hes_tag_bar];
    if(nil != v)
    {
        v.alpha = 1.0;
        NSLog(@"v");
        return;
    }
    
    /* Allocate the filter bar */
    UIView *filterBar = [[UIView alloc]initWithFrame:CGRectMake(actualFrame.origin.x, actualFrame.origin.y, actualFrame.size.width,actualFrame.size.height)];
    filterBar.tag = hes_tag_bar;
    [self addSubview:filterBar];
    [filterBar release];
    
    
    /* Add gradient layer to it */
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = filterBar.bounds;
    gradient.colors = [NSArray arrayWithObjects:(id)[hes_GradientTopColor CGColor], (id)[hes_GradientBottomColor CGColor], nil];
    [filterBar.layer insertSublayer:gradient atIndex:0];
    
    /* Allocate scroll bar */
    UIScrollView *scrollBar = [[UIScrollView alloc] initWithFrame:CGRectMake(hes_closebutton_height, 0, actualFrame.size.width-hes_closebutton_height,actualFrame.size.height)];
    scrollBar.backgroundColor=[UIColor whiteColor];
    [filterBar addSubview:scrollBar];
    [scrollBar release];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    float x= hes_border_size;
    float y= hes_border_size;
    float width  = scrollBar.frame.size.height - (2*x);
    float height = width;
    float gap= height + x;
    
    for(int index = 0; index <= [self.hesldelegate numberOfItems]; index++)
    {
        UIButton   *button   = [[UIButton alloc]init];
        button.frame         = CGRectMake(x, y, width, height);
        button.tag           = index;
        button.backgroundColor = [UIColor blackColor];
        //NSLog(@"Frame %d (%f,%f,%f,%f)",index,x,y,width,height);
        
        [button addTarget:self  action:@selector(applyFrame:)  forControlEvents:UIControlEventTouchDown];
        //NSString *imageName=[NSString stringWithFormat:@"but_%d.png",index];
        //NSString *imageName = [NSString stringWithFormat:@"but_1.png"];
        [button setBackgroundImage:[self.hesldelegate imageForTheItemAtIndex:index] forState:UIControlStateNormal];
        button.showsTouchWhenHighlighted = YES;
        [scrollBar     addSubview:button];
        [button release];
        
        UILabel *label          =   [[UILabel alloc] init];
        label.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont boldSystemFontOfSize:hes_font_size];
        label.textAlignment     = UITextAlignmentCenter;
        label.frame             =   CGRectMake(0, height-15, width, 15);
        //label.text              =   [NSString stringWithFormat:@"Frame %d",index];
        label.text              = [self.hesldelegate nameOfTheItemAtIndex:index];
        //label.text              =   [FilterMapping nameOfTheBirthdayFrameAtIndex:index-1];
        [button     addSubview:label];
        [label                release];
        
        if(YES)
        {
            [button setImage:[UIImage imageNamed:@"lock.png"] forState:UIControlStateNormal];
        }
        else
        {
            [button setImage:nil forState:UIControlStateNormal];
        }
        
        x = x + gap;
    }
    
    scrollBar.contentSize = CGSizeMake(x,width);
    [scrollBar     setShowsHorizontalScrollIndicator:NO];
    [scrollBar     setShowsVerticalScrollIndicator:NO];
    
    [self addFrameForBar:filterBar withCloseAction:@selector(collapseAnyFramesScrollBars:)];
#if 0
    
    if (fValue==0)
    {
        
        fValue++;
    }
    else
    {
        [self addSound:@"page-flip-1"];
    }
#endif
    [UIView commitAnimations];
    
    return;
    
}

-(void)collapseAnyFramesScrollBars:(id)sender
{
    
    UIView *view = self;
    
    if(nil != view)
    {
        //[self addSound:@"page-flip-1"];
        [UIView animateWithDuration:0.5
                         animations:^{
                             [view setTransform:CGAffineTransformMakeScale(0.0, 1.0)];
                             view.center = CGPointMake(-view.center.x, view.center.y);
                         }
                         completion:^(BOOL finished)
         {
             [self.hesldelegate hesScrollViewWillExit:self];
             [view removeFromSuperview];
         }];
    }
    
    return;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
