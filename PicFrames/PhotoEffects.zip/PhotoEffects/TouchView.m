//
//  TouchView.m
//  MirroCamFx
//
//  Created by Vijaya kumar reddy Doddavala on 10/30/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import "TouchView.h"

@implementation TouchDetectView
@synthesize touchdelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.userInteractionEnabled = YES;
    }
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touchView: grabbed the touch");
    if([self.touchdelegate respondsToSelector:@selector(touchDetected:)])
    {
        [self.touchdelegate touchDetected:[touches anyObject]];
    }
    
    return;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
