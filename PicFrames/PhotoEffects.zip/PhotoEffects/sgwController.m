//
//  sgwController.m
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/10/12.
//
//

#import "sgwController.h"

@interface sgwController ()
{
    int _selectedItemIndex;
    UIImageView *_previewView;
}
@end

@implementation sgwController
@synthesize tag;
@synthesize backgroundView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)unregisterForNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:notification_sgwcontroller_updatepreview
                                                  object:nil];
}

-(void)registerForNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receiveNotification:)
                                                 name:notification_sgwcontroller_updatepreview
                                               object:nil];
}

-(void)receiveNotification:(NSNotification*)notify
{
    if([notify.name isEqualToString:notification_sgwcontroller_updatepreview])
    {
        _previewView.image = [self.sgw_delegate previewImageForSgwController:self];
    }
}

-(id)initWithDelegate:(id)del currentItem:(int)item
{
    self = [super init];
    if (self)
    {
        // Custom initialization
        self.sgw_delegate = del;
        _selectedItemIndex = item;
        _previewView = nil;
        
        [self registerForNotifications];
        
        /* Add the background view */
        CGRect full = [[UIScreen mainScreen]bounds];
        UIImageView *bgnd = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, full.size.width, full.size.height-SGW_ITEM_SIZE-50)];
        self.backgroundView = bgnd;
        [self.view addSubview:bgnd];
        [bgnd release];
    }
    
    return self;
}

-(void)applyItem:(UIButton*)sender
{
    int index = sender.tag;
    BOOL isLocked = [self.sgw_delegate sgwController:self isItemLockedAtIndex:index];
    
    /* If the item is locked then  */
    if(isLocked == NO)
    {
        _selectedItemIndex = index;
    }
    
    [self.sgw_delegate sgwController:self itemDidSelectAtIndex:index];
}

-(void)addItems
{
    CGRect full = [[UIScreen mainScreen]bounds];
    
    /* Allocate the filter bar */
    UIView *filterBar = [[UIView alloc]initWithFrame:CGRectMake(full.origin.x, full.size.height - SGW_ITEM_SIZE, full.size.width,SGW_ITEM_SIZE)];
    //filterBar.tag = hes_tag_bar;
    [self.view addSubview:filterBar];
    [filterBar release];
    
#if 0
    /* Add gradient layer to it */
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = filterBar.bounds;
    gradient.colors = [NSArray arrayWithObjects:(id)[hes_GradientTopColor CGColor], (id)[hes_GradientBottomColor CGColor], nil];
    [filterBar.layer insertSublayer:gradient atIndex:0];
#endif
    /* Allocate scroll bar */
    UIScrollView *scrollBar = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, filterBar.frame.size.width,filterBar.frame.size.height)];
    scrollBar.backgroundColor=[UIColor whiteColor];
    [filterBar addSubview:scrollBar];
    [scrollBar release];
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5];
    
    float x= SGW_ITEM_BORDER_SIZE;
    float y= SGW_ITEM_BORDER_SIZE;
    float width  = scrollBar.frame.size.height - (2*x);
    float height = width;
    float gap= height + x;
    
    for(int index = 0; index <= [self.sgw_delegate numberOfItemsInSqwController:self]; index++)
    {
        UIButton   *button   = [[UIButton alloc]init];
        button.frame         = CGRectMake(x, y, width, height);
        button.tag           = index;
        button.backgroundColor = [UIColor blackColor];
        //NSLog(@"Frame %d (%f,%f,%f,%f)",index,x,y,width,height);
        
        [button addTarget:self  action:@selector(applyItem:)  forControlEvents:UIControlEventTouchDown];
        //NSString *imageName=[NSString stringWithFormat:@"but_%d.png",index];
        //NSString *imageName = [NSString stringWithFormat:@"but_1.png"];
        
        [button setBackgroundImage:[self.sgw_delegate sgwController:self imageForTheItemAtIndex:index] forState:UIControlStateNormal];
        button.showsTouchWhenHighlighted = YES;
        [scrollBar     addSubview:button];
        [button release];
        
        UILabel *label          =   [[UILabel alloc] init];
        label.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont boldSystemFontOfSize:SGW_FONT_SIZE];
        label.textAlignment     = UITextAlignmentCenter;
        label.frame             =   CGRectMake(0, height-15, width, 15);
        //label.text              =   [NSString stringWithFormat:@"Frame %d",index];
        label.text              = [self.sgw_delegate sgwController:self titleForTheItemAtIndex:index];
        //label.text              =   [FilterMapping nameOfTheBirthdayFrameAtIndex:index-1];
        [button     addSubview:label];
        [label                release];
        
        if([self.sgw_delegate sgwController:self isItemLockedAtIndex:index])
        {
            [button setImage:[UIImage imageNamed:@"lock.png"] forState:UIControlStateNormal];
        }
        else
        {
            [button setImage:nil forState:UIControlStateNormal];
        }
        
        x = x + gap;
    }
    
    scrollBar.contentSize = CGSizeMake(x,width);
    [scrollBar     setShowsHorizontalScrollIndicator:NO];
    [scrollBar     setShowsVerticalScrollIndicator:NO];

    //[self addFrameForBar:filterBar withCloseAction:@selector(collapseAnyFramesScrollBars:)];

    [UIView commitAnimations];
    
    return;
}

-(void)handleCancel:(id)sender
{
    [self unregisterForNotifications];
    [self.sgw_delegate sgwControllerDidCancel:self];
    [self dismissModalViewControllerAnimated:NO];
}

-(void)handleDone:(id)sender
{
    [self unregisterForNotifications];
    [self.sgw_delegate sgwController:self didDoneSelectingItemAtIndex:_selectedItemIndex];
    
    [self dismissModalViewControllerAnimated:NO];
}

-(void)addToolBar
{
    CGRect full = [[UIScreen mainScreen]bounds];
    UIToolbar *tb = [[UIToolbar alloc]initWithFrame:CGRectMake(0, full.size.height-SGW_ITEM_SIZE-50.0, full.size.width, 50.0)];
    tb.barStyle = UIBarStyleBlackOpaque;
    
    UIBarButtonItem *cancel = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(handleCancel:)];
    UIBarButtonItem *done = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(handleDone:)];
    UIBarButtonItem *flex = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    tb.items = [NSArray arrayWithObjects:cancel,flex,done, nil];
    
    [self.view addSubview:tb];
    
    [tb release];
    [cancel release];
    [done release];
    [flex release];
    //tb.items
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    /* Add Items */
    [self addItems];
    
    /* Add toolbar */
    [self addToolBar];
    
    
    
    /* add the preview view */
    //CGRect full = [[UIScreen mainScreen]bounds];
    if([self.sgw_delegate respondsToSelector:@selector(previewViewForSgwController:)])
    {
        _previewView = [self.sgw_delegate previewViewForSgwController:self];
    }
    
    if(nil == _previewView)
    {
        CGRect previewRect = CGRectMake(10.0, 10.0, self.backgroundView.frame.size.width-20, self.backgroundView.frame.size.height-20);
        _previewView =[[UIImageView alloc]initWithFrame:previewRect];
        [self.view addSubview:_previewView];
        [_previewView release];
    }
    else
    {
        [self.view addSubview:_previewView];
    }
    
    _previewView.contentMode = UIViewContentModeScaleAspectFit;
    
    //_previewView.center = CGPointMake(self.backgroundView.center.x - self.backgroundView.frame.origin.x, self.backgroundView.center.y - self.backgroundView.frame.origin.y);
    _previewView.center = self.view.center;
    _previewView.image = [self.sgw_delegate previewImageForSgwController:self];
    
    [self.view bringSubviewToFront:_previewView];

    return;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
