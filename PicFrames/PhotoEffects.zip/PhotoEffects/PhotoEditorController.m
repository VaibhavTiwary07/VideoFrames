//
//  PhotoEditorController.m
//  MirroFx
//
//  Created by Vijaya kumar reddy Doddavala on 10/15/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import "PhotoEditorController.h"
#import "UIImage+Resize.h"

@interface PhotoEditorController ()
{
    UIImage *_inputImage;
    UIImage *_smallImage;
    UIImage *_curImage;
    UIImageView *_activityView;
    UIImageView *_leftGpuImage;
#if PHOTOEFFECTS_MIRROR_SUPPORT
    UIImageView *_rightGpuImage;
    eMirror _eCurMirror;
#endif
#if PHOTOEFFECTS_SHARE_SUPPORT
    CMPopTipView *_shareTipView;
    UIDocumentInteractionController *documentInteractionController;
#endif
    int _curGrpId;
    int _curFilter;
    
    int _undoIndex;
    int _maxIndex;
    UIBarButtonItem *_undoButton;
    UIBarButtonItem *_redoButton;
    PopupMenu       *_lockedMenu;
}

@property(nonatomic,retain)UIImage *_inputImage;
@property(nonatomic,retain)UIImage *_smallImage;
@end

@implementation PhotoEditorController
@synthesize _inputImage;
@synthesize _smallImage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#if PHOTOEFFECTS_MIRROR_SUPPORT
-(id)initWithImage:(UIImage*)img andMirror:(eMirror)mirror
{
    self = [super init];
    if (self)
    {
        // Custom initialization
        self._inputImage = img;
        self._smallImage = nil;
        
        UIImageView *lview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, full_screen.size.width, full_screen.size.width)];
        lview.contentMode = UIViewContentModeScaleAspectFill;
        lview.image = self._inputImage;

        self._inputImage = [self getOutputImageFromView:lview ofScale:self._inputImage.size.width/full_screen.size.width];
        [lview release];

        NSLog(@"Image Orientation while Opening %d",img.imageOrientation);
        _eCurMirror = mirror;
        _undoIndex = 0;
        _maxIndex = 0;
        [self saveUndoImage:self._inputImage forUndoIndex:_undoIndex];
        _inApp = [[InAppPurchaseManager alloc]init];
        [_inApp loadStore];
    }
    return self;
}
#endif

+(CGRect)frameForImage:(UIImage*)image inRectAspectFit:(CGRect)frame
{
    
    CGRect rect;
    
    float imageRatio = image.size.width / image.size.height;
    
    float viewRatio = frame.size.width / frame.size.height;
    
    if(imageRatio < viewRatio)
    {
        float scale = frame.size.height / image.size.height;
        
        float width = scale * image.size.width;
        
        float topLeftX = (frame.size.width - width) * 0.5;
        
        rect = CGRectMake(topLeftX, 0, width, frame.size.height);
    }
    else
    {
        float scale = frame.size.width / image.size.width;
        
        float height = scale * image.size.height;
        
        float topLeftY = (frame.size.height - height) * 0.5;
        
        rect = CGRectMake(0, topLeftY, frame.size.width, height);
    }
#if 0
    int converter;
    
    converter        = rect.origin.x;
    rect.origin.x    = converter;
    converter        = rect.origin.y;
    rect.origin.y    = converter;
    converter        = rect.size.width;
    rect.size.width  = converter;
    converter        = rect.size.height;
    rect.size.height = converter;
#endif
    return rect;
}

-(id)initWithImage:(UIImage*)img
{
    self = [super init];
    if (self)
    {
        // Custom initialization
        self._inputImage = img;
        self._smallImage = nil;
        
        CGRect originalRect = CGRectMake(0, 0, PHOTOEFFECTS_IMAGEDISPLAYVIEW_WIDTH, PHOTOEFFECTS_IMAGEDISPLAYVIEW_HEIGHT);
        CGRect aspectRect = [PhotoEditorController frameForImage:img inRectAspectFit:originalRect];
        
        UIImageView *lview = [[UIImageView alloc]initWithFrame:aspectRect];
        lview.contentMode = PHOTOEFFECTS_CONTENT_MODE;
        lview.image = self._inputImage;
        
        self._inputImage = [self getOutputImageFromView:lview ofScale:self._inputImage.size.width/aspectRect.size.width];

        [lview release];
#if PHOTOEFFECTS_MIRROR_SUPPORT
        _eCurMirror = MIRROR_NONE;
#endif
        _undoIndex = 0;
        _maxIndex = 0;
        [self saveUndoImage:self._inputImage forUndoIndex:_undoIndex];
#if PHOTOEFFECTS_INAPP_SUPPORT
        [[InAppPurchaseManager Instance]loadStore];
#endif
        
        NSLog(@"Current Tapjoy points %d",[tapPoints Instance].curScore);
        
    }
    return self;
}

-(void)saveUndoImage:(UIImage*)img forUndoIndex:(int)index
{
    if(nil == img)
    {
        NSLog(@"saveUndoImage:Invalid image");
        return;
    }
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *docDirectory = [paths objectAtIndex:0];
    NSData *data           = UIImageJPEGRepresentation(img,1.0);
    NSFileManager *filemgr = [NSFileManager defaultManager];
    NSString *filename     = [NSString stringWithFormat:@"undo%d.png",index];
    NSString *path         = [docDirectory stringByAppendingPathComponent:filename];
    NSMutableDictionary *attributes = [NSMutableDictionary dictionaryWithCapacity:1];
    [attributes setObject:[NSNumber numberWithInt:511] forKey:NSFilePosixPermissions];
    
    if(NO == [filemgr createFileAtPath:path contents:data attributes:attributes])
    {
        NSLog(@"saveUndoImage:Failed to save the file");
    }
    else
    {
        
    }
    
    return;
}

-(void)deleteUndoImagesFrom:(int)from
{
    NSAutoreleasePool *localPool     = [[NSAutoreleasePool alloc] init];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *docDirectory = [paths objectAtIndex:0];
    NSFileManager *filemgr = [NSFileManager defaultManager];
    NSString *filename = nil;
    NSString *path = nil;
    int inputFrom = from;
    
    /* check the undo index and return */
    
    while(TRUE)
    {
        filename = [NSString stringWithFormat:@"undo%d.png",from];
        path     = [docDirectory stringByAppendingPathComponent:filename];
        
        /* Now delete color file */
        if([filemgr fileExistsAtPath:path])
        {
            NSError *error;
            if(NO == [filemgr removeItemAtPath:path error:&error])
            {
                NSLog(@"Failed to delete %@",filename);
            }
        }
        else
        {
            NSLog(@"deleteUndoImagesFrom: File %@ doesn't exist(from %d)",filename,inputFrom);
            break;
        }
        
        from = from+1;
    }
    
    [localPool release];
    
    return;
}

-(void)deleteUndoImageFromIndex:(int)from to:(int)to
{
    NSAutoreleasePool *localPool     = [[NSAutoreleasePool alloc] init];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *docDirectory = [paths objectAtIndex:0];
    NSFileManager *filemgr = [NSFileManager defaultManager];
    NSString *filename = nil;
    NSString *path = nil;
    
    /* check the undo index and return */
    if(to < from)
    {
        NSLog(@"releaseUndoImageFromIndex: To(%d) is less than or equal to From(%d)",to,from);
        [localPool release];
        return;
    }
    
    while(from<=to)
    {
        filename = [NSString stringWithFormat:@"undo%d.png",from];
        path     = [docDirectory stringByAppendingPathComponent:filename];
        
        /* Now delete color file */
        if([filemgr fileExistsAtPath:path])
        {
            NSError *error;
            if(NO == [filemgr removeItemAtPath:path error:&error])
            {
                NSLog(@"Failed to delete %@",filename);
            }
        }
        
        from = from+1;
    }
    
    [localPool release];
    
    return;
}

-(UIImage*)imageForUndoIndex:(int)undo
{
    NSArray *paths         = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *docDirectory = [paths objectAtIndex:0];
    NSFileManager *filemgr = [NSFileManager defaultManager];
    NSString *filename     = [NSString stringWithFormat:@"undo%d.png",undo];
    NSString *path         = [docDirectory stringByAppendingPathComponent:filename];
    
    if([filemgr fileExistsAtPath:path])
    {
        UIImage *img      = [UIImage imageWithContentsOfFile:path];
        
        if(undo == 0)
        {
            if([[NSUserDefaults standardUserDefaults]boolForKey:@"key_needrotation"])
            {
                img = [UIImage imageWithCGImage:img.CGImage scale:1.0 orientation:UIImageOrientationRight];
                //img = [[UIImage alloc] initWithCGImage: img.CGImage
                //                                 scale: 1.0
                //                           orientation: UIImageOrientationRight];
            }
        }
        NSLog(@"mage Orieintation is %d",img.imageOrientation);
        return img;
    }
    else{
        NSLog(@"imageForUndoIndex: File %@ doesn't exist",filename);
    }
    
    return nil;
}

-(UIImage*)getOutputImageFromView:(UIView*)v ofScale:(float)scale
{
    if(nil == v)
    {
        return nil;
    }
    
    UIGraphicsBeginImageContextWithOptions(v.frame.size, NO, scale);
    [v.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image1 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImage *image = [UIImage imageWithCGImage:image1.CGImage];
    
    return image;
}

-(UIImage*)getOutputImageOfScale:(float)scale
{
    
    UIView *viewFinder = [self.view viewWithTag:tag_singleviewfinder];
    if(nil == viewFinder)
    {
        viewFinder = [self.view viewWithTag:tag_viewfinder];
        if(nil == viewFinder)
        {
            return nil;
        }
    }
    
    UIGraphicsBeginImageContextWithOptions(viewFinder.frame.size, NO, scale);
    [viewFinder.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image1 = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImage *image = [UIImage imageWithCGImage:image1.CGImage];
    
    return image;
}

-(UIImage*)getOutputImage
{
    UIView *viewFinder = [self.view viewWithTag:tag_singleviewfinder];
    if(nil == viewFinder)
    {
        viewFinder = [self.view viewWithTag:tag_viewfinder];
        if(nil == viewFinder)
        {
            return nil;
        }
    }
    
    int   num1  = self._inputImage.size.width;
    int   num2  = viewFinder.frame.size.width;
    float scale = 1.0;
    
    if(0 == (num1 % num2))
    {
        scale = num1/num2;
    }
    else
    {
        scale = (float)num1/(float)num2;
    }
    
    return [self getOutputImageOfScale:scale];
}

- (UIView *) flipImgView:(UIView *)originalImage Horizontal:(BOOL)flipHorizontal {
    if (flipHorizontal)
    {
        
        originalImage.transform = CGAffineTransformMake(originalImage.transform.a * -1, 0, 0, 1, originalImage.transform.tx, 0);
    }
    else
    {
        
        originalImage.transform = CGAffineTransformMake(1, 0, 0, originalImage.transform.d * -1, 0, originalImage.transform.ty);
    }
    return originalImage;
}
#if PHOTOEFFECTS_MIRROR_SUPPORT
-(UIView*)getStrightMirror:(eMirror)mirror withLeftImage:(UIView*)l rightImage:(UIView*)r
{
    if((mirror != MIRROR_LEFT_HORIZANTAL)&&(mirror != MIRROR_RIGHT_HORIZANTAL)&&(mirror != MIRROR_UP_VERTIVAL)&&(mirror != MIRROR_DOWN_VERTIVAL))
    {
        NSLog(@"implementStrightMirror: Input Mirror %d is not supported",mirror);
        return nil;
    }
    
    //CGRect fullScreen = [[UIScreen mainScreen]bounds];
    float           x = 0.0;
    float           y = camera_y_position;
    UIView *left      = nil;
    UIView *right     = nil;
    
    /* Allocate view finder */
    UIView *viewFinder = [[UIView alloc]initWithFrame:CGRectMake(x,y,l.frame.size.width,l.frame.size.width)];
    viewFinder.layer.masksToBounds = YES;
    viewFinder.tag = tag_viewfinder;
    //[self.view addSubview:viewFinder];
    //[viewFinder release];
    
    /* Allocate two UIViews */
    left = [[UIView alloc]initWithFrame:CGRectMake(0,0,l.frame.size.width,l.frame.size.width)];
    //left.tag = tag_leftmirror;
    
    if((mirror == MIRROR_LEFT_HORIZANTAL)||(mirror == MIRROR_RIGHT_HORIZANTAL))
    {
        right = [[UIView alloc]initWithFrame:CGRectMake((l.frame.size.width/2.0),0,l.frame.size.width/2.0,l.frame.size.width)];
    }
    else
    {
        right = [[UIView alloc]initWithFrame:CGRectMake(0,(l.frame.size.width/2.0),l.frame.size.width,l.frame.size.width/2.0)];
    }
    //right.tag = tag_rightmirror;
    right.layer.masksToBounds = YES;
    left.layer.masksToBounds = YES;
    
    [viewFinder addSubview:left];
    [viewFinder addSubview:right];
    
    [left release];
    [right release];
    
    /* Allocate Mirror Left view */
    UIView *mirrorLeft = [[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, l.frame.size.width, l.frame.size.width)];
    mirrorLeft.layer.masksToBounds = YES;
    
    /* Allocate Mirror right view */
    UIView *mirrorRight = [[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, l.frame.size.width, l.frame.size.width)];
    mirrorRight.layer.masksToBounds = YES;
    
    [mirrorRight addSubview:r];
    [mirrorLeft addSubview:l];
    
    switch(mirror)
    {
        case MIRROR_LEFT_HORIZANTAL:
        {
            mirrorRight = [self flipImgView:mirrorRight Horizontal:YES];
            mirrorRight.frame = CGRectMake(-l.frame.size.width/2.0, 0, l.frame.size.width, l.frame.size.width);
            break;
        }
        case MIRROR_RIGHT_HORIZANTAL:
        {
            mirrorLeft = [self flipImgView:mirrorLeft Horizontal:YES];
            //mirrorLeft.frame = CGRectMake(-fullScreen.size.width/2.0, 0, fullScreen.size.width, height);
            mirrorRight.frame = CGRectMake(-l.frame.size.width/2.0, 0, l.frame.size.width, l.frame.size.width);
            break;
        }
        case MIRROR_UP_VERTIVAL:
        {
            mirrorRight = [self flipImgView:mirrorRight Horizontal:NO];
            mirrorRight.frame = CGRectMake(0, (mirrorRight.frame.size.width/2.0)-l.frame.size.width, mirrorRight.frame.size.width, mirrorRight.frame.size.height);
            break;
        }
        case MIRROR_DOWN_VERTIVAL:
        {
            mirrorLeft = [self flipImgView:mirrorLeft Horizontal:NO];
            //mirrorLeft.frame = CGRectMake(0, (mirrorLeft.frame.size.width/2.0)-height, mirrorLeft.frame.size.width, mirrorLeft.frame.size.height);
            mirrorRight.frame = CGRectMake(0, (mirrorRight.frame.size.width/2.0)-l.frame.size.width, mirrorRight.frame.size.width, mirrorRight.frame.size.height);
            break;
        }
        default:
        {
            break;
        }
    }
    
    /* Add Left mirror to UIView left view */
    [left addSubview:mirrorLeft];
    
    /* Add right mittor to UIView right view */
    [right addSubview:mirrorRight];
    
    [mirrorLeft release];
    [mirrorRight release];
    
    return viewFinder;
}

-(UIView*)getCrossMirror:(eMirror)mirror withLeftImage:(UIView*)l rightImage:(UIView*)r
{
    //CGRect fullScreen = [[UIScreen mainScreen]bounds];
    float x = 0.0;
    float y = camera_y_position;
    
    if((mirror != MIRROR_TOP_LEFT)&&(mirror != MIRROR_TOP_RIGHT)&&(mirror != MIRROR_BOTTOM_LEFT)&&(mirror != MIRROR_BOTTOM_RIGHT))
    {
        NSLog(@"applyCrossMirror: Input Mirror %d is not supported",mirror);
        return nil;
    }
    
    /* Allocate view finder */
    UIView *viewFinder = [[UIView alloc]initWithFrame:CGRectMake(x,y,l.frame.size.width,l.frame.size.width)];
    viewFinder.layer.masksToBounds = YES;
    viewFinder.tag = tag_viewfinder;
    //[self.view addSubview:viewFinder];
    //[viewFinder release];
    //viewFinder.backgroundColor = [UIColor whiteColor];
    
    /* Allocate left and right views */
    UIView *left = [[UIView alloc]initWithFrame:CGRectMake(0,0,l.frame.size.width*sqrt(2),l.frame.size.width*sqrt(2))];
    //left.backgroundColor = [UIColor greenColor];
    UIView *right = [[UIView alloc]initWithFrame:CGRectMake(0,0,l.frame.size.width*sqrt(2),l.frame.size.width*sqrt(2))];
    //right.backgroundColor = [UIColor redColor];
    [viewFinder addSubview:left];
    [viewFinder addSubview:right];
    right.layer.masksToBounds = YES;
    [left release];
    [right release];
    
    /* Position the left and right to the middle of view finder */
    left.center = CGPointMake(viewFinder.center.x-viewFinder.frame.origin.x, viewFinder.center.y-viewFinder.frame.origin.y);
    right.center = left.center;
    
    /* Add left and right videos to left and right views and position them to the middle of view finder */
    UIView *videoLeft = [[UIView alloc]initWithFrame:CGRectMake(0, 0, l.frame.size.width, l.frame.size.width)];
    
    UIView *videoRight = [[UIView alloc]initWithFrame:CGRectMake(0, 0, l.frame.size.width, l.frame.size.width)];
    
    [left addSubview:videoLeft];
    [right addSubview:videoRight];
    [videoLeft release];
    [videoRight release];

    [videoLeft addSubview:l];
    [videoRight addSubview:r];

    /* position video views to the middle of view finder */
    videoLeft.center = CGPointMake(left.center.x-left.frame.origin.x, left.center.y-left.frame.origin.y);
    videoRight.center = videoLeft.center;
    
    /* Now flip the right view */
    if((mirror == MIRROR_TOP_LEFT)||(mirror == MIRROR_BOTTOM_RIGHT))
    {
        videoRight = [self flipImgView:videoRight Horizontal:NO];
    }
    else
    {
        videoRight = [self flipImgView:videoRight Horizontal:YES];
    }
    
    /* Now do the rotation part */
    videoRight.transform = CGAffineTransformRotate(videoRight.transform, 135*(CGFloat)(M_PI/180.0));
    
    switch(mirror)
    {
        case MIRROR_TOP_LEFT:
        {
            videoRight.center = CGPointMake(videoRight.center.x+(videoRight.frame.size.width/2.0), videoRight.center.y);
            right.center = CGPointMake(0, 0);
            break;
        }
        case MIRROR_TOP_RIGHT:
        {
            videoRight.center = CGPointMake(videoRight.center.x, videoRight.center.y+(videoRight.frame.size.width/2.0));
            right.center = CGPointMake(viewFinder.frame.size.width, 0);
            break;
        }
        case MIRROR_BOTTOM_LEFT:
        {
            videoRight.center = CGPointMake(videoRight.center.x, videoRight.center.y - (videoRight.frame.size.width/2.0));
            
            right.center = CGPointMake(0, viewFinder.frame.size.height);
            break;
        }
        case MIRROR_BOTTOM_RIGHT:
        {
            videoRight.center = CGPointMake(videoRight.center.x - (videoRight.frame.size.width/2.0), videoRight.center.y);
            
            right.center = CGPointMake(viewFinder.frame.size.width, viewFinder.frame.size.height);
            break;
        }
        default:
        {
            break;
        }
    }
    
    right.transform = CGAffineTransformRotate(right.transform, 45*(CGFloat)(M_PI/180.0));
    
    return viewFinder;
}
-(void)applyStrightMirror:(eMirror)mirror withLeftImage:(UIView*)l rightImage:(UIView*)r
{
    if((mirror != MIRROR_LEFT_HORIZANTAL)&&(mirror != MIRROR_RIGHT_HORIZANTAL)&&(mirror != MIRROR_UP_VERTIVAL)&&(mirror != MIRROR_DOWN_VERTIVAL))
    {
        NSLog(@"implementStrightMirror: Input Mirror %d is not supported",mirror);
        return;
    }
    
    CGRect fullScreen = [[UIScreen mainScreen]bounds];
    float           x = 0.0;
    float           y = camera_y_position;
    UIView *left      = nil;
    UIView *right     = nil;
    
    /* Allocate view finder */
    UIView *viewFinder = [[UIView alloc]initWithFrame:CGRectMake(x,y,fullScreen.size.width,fullScreen.size.width)];
    viewFinder.layer.masksToBounds = YES;
    viewFinder.tag = tag_viewfinder;
    [self.view addSubview:viewFinder];
    [viewFinder release];
    
    /* Allocate two UIViews */
    left = [[UIView alloc]initWithFrame:CGRectMake(0,0,fullScreen.size.width,fullScreen.size.width)];
    //left.tag = tag_leftmirror;
    
    if((mirror == MIRROR_LEFT_HORIZANTAL)||(mirror == MIRROR_RIGHT_HORIZANTAL))
    {
        right = [[UIView alloc]initWithFrame:CGRectMake((fullScreen.size.width/2.0),0,fullScreen.size.width/2.0,fullScreen.size.width)];
    }
    else
    {
        right = [[UIView alloc]initWithFrame:CGRectMake(0,(fullScreen.size.width/2.0),fullScreen.size.width,fullScreen.size.width/2.0)];
    }
    //right.tag = tag_rightmirror;
    right.layer.masksToBounds = YES;
    left.layer.masksToBounds = YES;
    
    [viewFinder addSubview:left];
    [viewFinder addSubview:right];
    
    [left release];
    [right release];
    
    /* Allocate Mirror Left view */
    UIView *mirrorLeft = [[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, fullScreen.size.width, fullScreen.size.width)];
    mirrorLeft.layer.masksToBounds = YES;
    
    /* Allocate Mirror right view */
    UIView *mirrorRight = [[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, fullScreen.size.width, fullScreen.size.width)];
    mirrorRight.layer.masksToBounds = YES;
    
    [mirrorRight addSubview:r];
    [mirrorLeft addSubview:l];
    
    switch(mirror)
    {
        case MIRROR_LEFT_HORIZANTAL:
        {
            mirrorRight = [self flipImgView:mirrorRight Horizontal:YES];
            mirrorRight.frame = CGRectMake(-fullScreen.size.width/2.0, 0, fullScreen.size.width, fullScreen.size.width);
            break;
        }
        case MIRROR_RIGHT_HORIZANTAL:
        {
            mirrorLeft = [self flipImgView:mirrorLeft Horizontal:YES];
            //mirrorLeft.frame = CGRectMake(-fullScreen.size.width/2.0, 0, fullScreen.size.width, height);
            mirrorRight.frame = CGRectMake(-fullScreen.size.width/2.0, 0, fullScreen.size.width, fullScreen.size.width);
            break;
        }
        case MIRROR_UP_VERTIVAL:
        {
            mirrorRight = [self flipImgView:mirrorRight Horizontal:NO];
            mirrorRight.frame = CGRectMake(0, (mirrorRight.frame.size.width/2.0)-fullScreen.size.width, mirrorRight.frame.size.width, mirrorRight.frame.size.height);
            break;
        }
        case MIRROR_DOWN_VERTIVAL:
        {
            mirrorLeft = [self flipImgView:mirrorLeft Horizontal:NO];
            //mirrorLeft.frame = CGRectMake(0, (mirrorLeft.frame.size.width/2.0)-height, mirrorLeft.frame.size.width, mirrorLeft.frame.size.height);
            mirrorRight.frame = CGRectMake(0, (mirrorRight.frame.size.width/2.0)-fullScreen.size.width, mirrorRight.frame.size.width, mirrorRight.frame.size.height);
            break;
        }
        default:
        {
            break;
        }
    }
    
    /* Add Left mirror to UIView left view */
    [left addSubview:mirrorLeft];
    
    /* Add right mittor to UIView right view */
    [right addSubview:mirrorRight];
    
    [mirrorLeft release];
    [mirrorRight release];
    
    return;
}

-(void)applyCrossMirror:(eMirror)mirror withLeftImage:(UIView*)l rightImage:(UIView*)r
{
    CGRect fullScreen = [[UIScreen mainScreen]bounds];
    float x = 0.0;
    float y = camera_y_position;
    
    if((mirror != MIRROR_TOP_LEFT)&&(mirror != MIRROR_TOP_RIGHT)&&(mirror != MIRROR_BOTTOM_LEFT)&&(mirror != MIRROR_BOTTOM_RIGHT))
    {
        NSLog(@"applyCrossMirror: Input Mirror %d is not supported",mirror);
        return;
    }
    
    /* Allocate view finder */
    UIView *viewFinder = [[UIView alloc]initWithFrame:CGRectMake(x,y,fullScreen.size.width,fullScreen.size.width)];
    viewFinder.layer.masksToBounds = YES;
    viewFinder.tag = tag_viewfinder;
    [self.view addSubview:viewFinder];
    [viewFinder release];
    viewFinder.backgroundColor = [UIColor whiteColor];
    
    /* Allocate left and right views */
    UIView *left = [[UIView alloc]initWithFrame:CGRectMake(0,0,fullScreen.size.width*sqrt(2),fullScreen.size.width*sqrt(2))];
    //left.backgroundColor = [UIColor greenColor];
    UIView *right = [[UIView alloc]initWithFrame:CGRectMake(0,0,fullScreen.size.width*sqrt(2),fullScreen.size.width*sqrt(2))];
    //right.backgroundColor = [UIColor redColor];
    [viewFinder addSubview:left];
    [viewFinder addSubview:right];
    right.layer.masksToBounds = YES;
    [left release];
    [right release];
    
    /* Position the left and right to the middle of view finder */
    left.center = CGPointMake(viewFinder.center.x-viewFinder.frame.origin.x, viewFinder.center.y-viewFinder.frame.origin.y);
    right.center = left.center;
    
    /* Add left and right videos to left and right views and position them to the middle of view finder */
    UIView *videoLeft = [[UIView alloc]initWithFrame:CGRectMake(0, 0, fullScreen.size.width, fullScreen.size.width)];
    
    UIView *videoRight = [[UIView alloc]initWithFrame:CGRectMake(0, 0, fullScreen.size.width, fullScreen.size.width)];
    
    [left addSubview:videoLeft];
    [right addSubview:videoRight];
    [videoLeft release];
    [videoRight release];
#if 0
    [videoLeft addSubview:_leftGpuImage];
    [videoRight addSubview:_rightGpuImage];
    //[_rightImage release];
    //[_leftImage release];
#else
    [videoLeft addSubview:l];
    [videoRight addSubview:r];
#endif
    /* position video views to the middle of view finder */
    videoLeft.center = CGPointMake(left.center.x-left.frame.origin.x, left.center.y-left.frame.origin.y);
    videoRight.center = videoLeft.center;
    
    /* Now flip the right view */
    if((mirror == MIRROR_TOP_LEFT)||(mirror == MIRROR_BOTTOM_RIGHT))
    {
        videoRight = [self flipImgView:videoRight Horizontal:NO];
    }
    else
    {
        videoRight = [self flipImgView:videoRight Horizontal:YES];
    }
    
    /* Now do the rotation part */
    videoRight.transform = CGAffineTransformRotate(videoRight.transform, 135*(CGFloat)(M_PI/180.0));
    
    switch(mirror)
    {
        case MIRROR_TOP_LEFT:
        {
            videoRight.center = CGPointMake(videoRight.center.x+(videoRight.frame.size.width/2.0), videoRight.center.y);
            right.center = CGPointMake(0, 0);
            break;
        }
        case MIRROR_TOP_RIGHT:
        {
            videoRight.center = CGPointMake(videoRight.center.x, videoRight.center.y+(videoRight.frame.size.width/2.0));
            right.center = CGPointMake(viewFinder.frame.size.width, 0);
            break;
        }
        case MIRROR_BOTTOM_LEFT:
        {
            videoRight.center = CGPointMake(videoRight.center.x, videoRight.center.y - (videoRight.frame.size.width/2.0));
            
            right.center = CGPointMake(0, viewFinder.frame.size.height);
            break;
        }
        case MIRROR_BOTTOM_RIGHT:
        {
            videoRight.center = CGPointMake(videoRight.center.x - (videoRight.frame.size.width/2.0), videoRight.center.y);
            
            right.center = CGPointMake(viewFinder.frame.size.width, viewFinder.frame.size.height);
            break;
        }
        default:
        {
            break;
        }
    }
    
    right.transform = CGAffineTransformRotate(right.transform, 45*(CGFloat)(M_PI/180.0));
}

-(void)addMirror:(eMirror)mirror
{
    
    /* First remove existing mirrors */
    [self removeAllMirrors];
    
    UIView *l = _leftGpuImage;
    UIView *r = _rightGpuImage;
    
    /* We donot show effect layer iin mirror mode */
    _activityView.image = nil;
    
    _eCurMirror = mirror;
    switch (mirror)
    {
        case MIRROR_LEFT_HORIZANTAL:
        case MIRROR_RIGHT_HORIZANTAL:
        case MIRROR_UP_VERTIVAL:
        case MIRROR_DOWN_VERTIVAL:
        {
            //[self applyStrightMirror:mirror withLeftImage:l rightImage:r];
            UIView *v = [self getStrightMirror:mirror withLeftImage:l rightImage:r];
            [self.view addSubview:v];
            [v release];
            break;
        }
        case MIRROR_BOTTOM_LEFT:
        case MIRROR_BOTTOM_RIGHT:
        case MIRROR_TOP_LEFT:
        case MIRROR_TOP_RIGHT:
        {
            //[self applyCrossMirror:mirror withLeftImage:l rightImage:r];
            UIView *v = [self getCrossMirror:mirror withLeftImage:l rightImage:r];
            [self.view addSubview:v];
            [v release];
            break;
        }
        case MIRROR_NONE:
        default:
        {
            //[self applyNoMirrorWithImage:l];
            UIView *v = [self getNoMirrorWithImage:l];
            [self.view addSubview:v];
            [v release];
            break;
        }
    }
}

-(UIImage*)applyMirrorOfType:(eMirror)mirror onImage:(UIImage*)img
{
    if(nil == img)
    {
        return nil;
    }
    
    if(img.size.height != img.size.width)
    {
        NSAssert(img.size.height == img.size.width, @"Image is not a sqaured image, so you may not get correct results");
        return nil;
    }
    
    UIView *v = nil;
    UIImageView *l = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, img.size.width, img.size.width)];
    l.contentMode = UIViewContentModeScaleAspectFill;
    UIImageView *r = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, img.size.width, img.size.width)];
    r.contentMode = UIViewContentModeScaleAspectFill;
    l.image = img;
    r.image = img;
    
    switch (mirror)
    {
        case MIRROR_LEFT_HORIZANTAL:
        case MIRROR_RIGHT_HORIZANTAL:
        case MIRROR_UP_VERTIVAL:
        case MIRROR_DOWN_VERTIVAL:
        {
            //[self applyStrightMirror:mirror withLeftImage:l rightImage:r];
            v = [self getStrightMirror:mirror withLeftImage:l rightImage:r];
            //[self.view addSubview:v];
            //[v release];
            break;
        }
        case MIRROR_BOTTOM_LEFT:
        case MIRROR_BOTTOM_RIGHT:
        case MIRROR_TOP_LEFT:
        case MIRROR_TOP_RIGHT:
        {
            //[self applyCrossMirror:mirror withLeftImage:l rightImage:r];
            v = [self getCrossMirror:mirror withLeftImage:l rightImage:r];
            //[self.view addSubview:v];
            //[v release];
            break;
        }
        case MIRROR_NONE:
        default:
        {
            //[self applyNoMirrorWithImage:l];
            v = [self getNoMirrorWithImage:l];
            //[self.view addSubview:v];
            //[v release];
            break;
        }
    }
    
    if(nil == v)
    {
        return nil;
    }
    
    return [self getOutputImageFromView:v ofScale:1.0];
}

-(void)applyMirror:(UIButton*)sender
{
    eMirror mirror = sender.tag;
    
    [self addMirror:mirror];
}

-(void)changeLense:(id)sender
{
    if(_eCurMirror < (MIRROR_LAST-1))
    {
        _eCurMirror = _eCurMirror + 1;
    }
    else{
        _eCurMirror = MIRROR_LEFT_HORIZANTAL;
    }
    
    [self addMirror:_eCurMirror];
    
    TimeoutImage *ti = [[TimeoutImage alloc]initWithFrame:CGRectMake(0, 0, 100.0, 100.0)];
    ti.image = [UIImage imageNamed:[NSString stringWithFormat:@"zero%d.png",_eCurMirror]];
    [ti showInView:self.view];
    ti.center = _activityView.center;
    [ti release];
    self._smallImage = nil;
    
    [[OT_AdControl sharedInstance]bringBannerAdToFrontInSuperView:self.view];
    
    [self exitEffectToolBar:nil];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_collapseOtherGroups object:nil];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_rearrangeTheGroups object:nil];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    if(touch.tapCount == 2)
    {
        //NSLog(@"Changing lense");
        [self changeLense:nil];
    }
}

#endif
-(UIView*)getNoMirrorWithImage:(UIView*)l
{
    //CGRect fullScreen = [[UIScreen mainScreen]bounds];
    float x = 0.0;
    float y = camera_y_position;
    
    /* Allocate view finder */
    UIView *viewFinder = [[UIView alloc]initWithFrame:CGRectMake(x,y,l.frame.size.width,l.frame.size.height)];
    viewFinder.layer.masksToBounds = YES;
    viewFinder.tag = tag_singleviewfinder;
    //[self.view addSubview:viewFinder];
    //[viewFinder release];
    
    //GPUImageView *video = [[GPUImageView alloc]initWithFrame:CGRectMake(0, 0, fullScreen.size.width, fullScreen.size.width)];
    //video.fillMode = kGPUImageFillModePreserveAspectRatioAndFill;
    
    //[viewFinder addSubview:_leftGpuImage];
    [viewFinder addSubview:l];
    //[_leftGpuImage release];
    //[video release];
    
    //video.center = CGPointMake(viewFinder.center.x - viewFinder.frame.origin.x, viewFinder.center.y-viewFinder.frame.origin.y);
    
    //[fil addTarget:video];
    
    return viewFinder;
}

//-(void)applyStrightMirror:(eMirror)mirror on:(GPUImageStillCamera*)fil


//-(void)applyNoMirrorOn:(GPUImageStillCamera*)fil
-(void)applyNoMirrorWithImage:(UIView*)l
{
    CGRect fullScreen = [[UIScreen mainScreen]bounds];
    float x = 0.0;
    float y = camera_y_position;
    
    /* Allocate view finder */
    UIView *viewFinder = [[UIView alloc]initWithFrame:CGRectMake(x,y,fullScreen.size.width,fullScreen.size.width)];
    viewFinder.layer.masksToBounds = YES;
    viewFinder.tag = tag_singleviewfinder;
    [self.view addSubview:viewFinder];
    [viewFinder release];
    
    //GPUImageView *video = [[GPUImageView alloc]initWithFrame:CGRectMake(0, 0, fullScreen.size.width, fullScreen.size.width)];
    //video.fillMode = kGPUImageFillModePreserveAspectRatioAndFill;
    
    //[viewFinder addSubview:_leftGpuImage];
    [viewFinder addSubview:l];
    //[_leftGpuImage release];
    //[video release];
    
    //video.center = CGPointMake(viewFinder.center.x - viewFinder.frame.origin.x, viewFinder.center.y-viewFinder.frame.origin.y);
    
    //[fil addTarget:video];
}

//-(void)applyCrossMirror:(eMirror)mirror on:(GPUImageStillCamera*)fil


-(void)removeAllMirrors
{
    UIView *view = [self.view viewWithTag:tag_viewfinder];
    if(nil != view)
    {
        if(nil != _leftGpuImage)
        {
            [_leftGpuImage removeFromSuperview];
#if PHOTOEFFECTS_MIRROR_SUPPORT
            [_rightGpuImage removeFromSuperview];
#endif
        }
        [view removeFromSuperview];
        view = nil;
    }
    
    view = [self.view viewWithTag:tag_singleviewfinder];
    if(nil != view)
    {
        if(nil != _leftGpuImage)
        {
            [_leftGpuImage removeFromSuperview];
        }
        [view removeFromSuperview];
        view = nil;
    }
    
    view = [self.view viewWithTag:tag_leftmirror];
    if(nil != view)
    {
        if(nil != _leftGpuImage)
        {
            [_leftGpuImage removeFromSuperview];
        }
        [view removeFromSuperview];
        view = nil;
    }
    
#if PHOTOEFFECTS_MIRROR_SUPPORT
    view = [self.view viewWithTag:tag_rightmirror];
    if(nil != view)
    {
        if(nil != _rightGpuImage)
        {
            [_rightGpuImage removeFromSuperview];
        }
        [view removeFromSuperview];
        view = nil;
    }
#endif

}

-(void)showMirrorOptions
{
    UIImageView *filterBar = nil;
    
    filterBar = [[UIImageView alloc ] initWithFrame:CGRectMake(0, full_screen.size.height -scrollbar_height, full_screen.size.width, scrollbar_height)];
    filterBar.image = [UIImage imageNamed:@"mainbackground.jpg"];
    //filterBar.tag = tag_filterbar;
    filterBar.userInteractionEnabled = YES;
    [self.view addSubview:filterBar];
    

    CGRect fullScreen = [[UIScreen mainScreen]bounds];
    efScrollView *efs = [[efScrollView alloc]initWithFrame:CGRectMake(0,0,fullScreen.size.width,100.0)];
    efs.userInteractionEnabled = YES;
    efs.efs_delegate = self;
    efs.efs_Group_delegate = self;
    [filterBar addSubview:efs];
    [efs start];
    [efs release];

    return;
    
}

-(UIImage*)applyStaticFilterOfGroup:(int)grpId atIndex:(int)index onImage:(UIImage*)img withAlpha:(float)alpha
{
    UIImage *outPut = nil;
    
    switch(grpId)
    {
        case GROUP_STATIC_GPU_FILTER_VINTAGE:
        case GROUP_STATIC_GPU_FILTER_COLOR:
        case GROUP_STATIC_GPU_FILTER_CARTOON:
        case GROUP_STATIC_GPU_FILTER_TONE:
        case GROUP_STATIC_GPU_FILTER_SKETCH:
        {
            outPut = [img applyGPUFilter:index onImage:img ofGroup:grpId withAlpha:alpha];
            break;
        }
        case GROUP_STATIC_FILTER_TEXTURE:
        {
            outPut = [img applyTexture:index onImageType:IMAGETYPE_FULLIMAGE withAlpha:alpha];
            break;
        }/*end of GROUP_LIVE_FILTER_TONES*/
        case GROUP_STATIC_FILTER_SPACE:
        {
            outPut = [img applySpaceTexture:index onImageType:IMAGETYPE_FULLIMAGE withAlpha:alpha];
            break;
        }/* end of GROUP_LIVE_FILTER_COLORS */
#if NOISESET_SUPPORT
        case GROUP_STATIC_FILTER_NOISE:
        {
            break;
        }/* end of GROUP_LIVE_FILTER_COLORS */
#endif
        case GROUP_STATIC_FILTER_GRUNGE:
        {
            outPut = [img applyGrungeTexture:index onImageType:IMAGETYPE_FULLIMAGE withAlpha:alpha];
            break;
        }
        case GROUP_STATIC_FILTER_BOKEH:
        {
            outPut = [img applyBokehTexture:index onImageType:IMAGETYPE_FULLIMAGE withAlpha:alpha];
            break;
        }
        case GROUP_STATIC_FILTER_LAST:
        default:
        {
            break;
        }
    }/* end of grpId switch */
    
    return outPut;
}

-(UIImage*)addStaticFilterOfGroup:(int)grpId atIndex:(int)index withAlpha:(float)alpha
{
    UIImage *outPut = nil;
    UIImage *temp = [_leftGpuImage.image retain];
    
    _leftGpuImage.image = [self applyStaticFilterOfGroup:grpId atIndex:index onImage:self._inputImage withAlpha:alpha];
#if PHOTOEFFECTS_MIRROR_SUPPORT
    _rightGpuImage.image = _leftGpuImage.image;
#endif
    outPut = _leftGpuImage.image;
    
    
    [self.view bringSubviewToFront:_activityView];
    //_activityView.image = [self getOutputImageOfScale:1.0];
    _activityView.image = outPut;
    
    _leftGpuImage.image = temp;
#if PHOTOEFFECTS_MIRROR_SUPPORT
    _rightGpuImage.image = temp;
#endif
    [temp release];
    
    return outPut;
}

//- (int)numberOfMenuOptions
- (int)numberOfItemsInPopupMenu:(PopupMenu*)sender
{
    return 3;
}

//- (NSString*)titleOfTheOptionAtIndex:(int)index
- (NSString*)popupMenu:(PopupMenu*)sender titleForItemAtIndex:(int)index
{
    NSString *title = @"Unlock it for FREE";
    if(index == 0)
    {
        title = @"Unlock All Effects $1.99";
    }
    else if(index == 1)
    {
        title = [NSString stringWithFormat:@"Unlock %@ pack $0.99",[StaticFilterMapping nameOfTheGroup:_curGrpId]];
    }
    
    return title;
}

//- (UIImage*)imageOfTheOptionAtIndex:(int)index
- (UIImage*)popupMenu:(PopupMenu*)sender imageForItemAtIndex:(int)index
{
    return [UIImage imageNamed:@"mail.png"];
}

//- (BOOL)shouldEnableTheOptionAtIndex:(int)index
- (BOOL)popupMenu:(PopupMenu*)sender enableStatusForItemAtIndex:(int)index
{
    return YES;
}

//- (void)PopupMenuDidDismiss:(PopupMenu*)popupmenu
- (void)popupMenuDidDismiss:(PopupMenu*)sender
{
    NSLog(@"Popup Dismissed");
}

-(void)continueUnlockingFilter:(NSTimer*)t
{
    /* unlock the content */
    [StaticFilterMapping setLockStatusOfFilter:_curFilter group:_curGrpId to:NO];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_updateGroupImages object:nil];
    
    [self removeLockedContentBarAndMenu];
    
    [self addEffectToolBar];
    
    /* show success alert with remaining points */
    UIAlertView *al = [[UIAlertView alloc]initWithTitle:@"Success" message:[NSString stringWithFormat:@"Congragulations!!, you have successfully unlocked the filter. Your current instapic points count is %d, would you like earn some more FREE points",[tapPoints Instance].curScore] delegate:self cancelButtonTitle: @"No Thanks" otherButtonTitles:@"Earn Free Points", nil];
    al.tag = tag_successfullunlockalert;
    [al show];
    [al release];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == tag_earnpointsalert)
    {
        if(buttonIndex == 0)
        {
            goalBasedOfferWallController *vc = [[goalBasedOfferWallController alloc]init];
            [self presentModalViewController:vc animated:YES];
            [vc release];
            
            return;
        }
    }
    else if(alertView.tag == tag_successfullunlockalert)
    {
        if(buttonIndex == 1)
        {
            goalBasedOfferWallController *vc = [[goalBasedOfferWallController alloc]init];
            [self presentModalViewController:vc animated:YES];
            [vc release];
            
            return;
        }
    }
    else if(alertView.tag == tag_discardchangesalert)
    {
        NSLog(@"Clicked button index %d",buttonIndex);
        if(buttonIndex == 1)
        {
            
        }
        else
        {
            [self unregisterForNotifications];
            
            [[NSNotificationCenter defaultCenter]postNotificationName:notification_donewithphotoeffectseditor  object:_leftGpuImage.image];
            
            [self dismissModalControllerWithFadeoutAnimation:self];
        }
    }
}

//- (void)PopupMenuDidSelectOptionAtIndex:(int)index
- (void)popupMenu:(PopupMenu*)sender itemDidSelectAtIndex:(int)index
{
    NSLog(@"PopupMenuDidSelectOptionAtIndex");
    if(index == 2)
    {
        /* check the current score and unlock the content if the score is enough,
         otherwise ask the user to earn the points */
        if([tapPoints Instance].curScore >= TAPPOINTS_TOUNLOCK_FILTER)
        {
            [[tapPoints Instance]spendPoints:TAPPOINTS_TOUNLOCK_FILTER];
            
            [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(continueUnlockingFilter:) userInfo:nil repeats:NO];
        }
        else
        {
            UIAlertView *al = [[UIAlertView alloc]initWithTitle:@"Not Enough Points" message:[NSString stringWithFormat:@"Your current instapic points count is %d, you need %d more points to unlock this filter",[tapPoints Instance].curScore,TAPPOINTS_TOUNLOCK_FILTER - [tapPoints Instance].curScore] delegate:self cancelButtonTitle:@"Earn Free Points" otherButtonTitles: nil];
            al.tag = tag_earnpointsalert;
            [al show];
            [al release];
        }
    }
    else if(index == 1)
    {
        [[InAppPurchaseManager Instance]puchaseProductWithId:[StaticFilterMapping productIdForGroup:_curGrpId]];
    }
    else if(index == 0)
    {
        [[InAppPurchaseManager Instance]puchaseProductWithId:photoeffects_AllEffects];
    }
    
    return;
}

-(void)addLockedContentBarAndMenu
{
    /* First Hide all the controls, so that user won't be able to use this
     effect */
    UIToolbar *effectBar = (UIToolbar*)[self.view viewWithTag:tag_lockedcontenttoolbar];
    if(nil != effectBar)
    {
        [effectBar removeFromSuperview];
        //return;
    }
    
    /* Add the toolbar */
    UIToolbar *lcBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, full_screen.size.height-scrollbar_height-toolbar_height+toolbar_sizeoffset, full_screen.size.width, toolbar_height-toolbar_sizeoffset)];
    lcBar.barStyle = UIBarStyleBlackOpaque;
    lcBar.tag = tag_lockedcontenttoolbar;
    
    /* Add the Button With Text For Full Version */
    UILabel *lblMsg = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, lcBar.frame.size.width, lcBar.frame.size.height)];
    lblMsg.backgroundColor = [UIColor clearColor];
    lblMsg.textAlignment = UITextAlignmentLeft;
    lblMsg.font = [UIFont boldSystemFontOfSize:15.0];
    lblMsg.textColor = [UIColor whiteColor];
    lblMsg.text = @"  Upgrade To Full Version";
    
    UILabel *lblPrice = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, lcBar.frame.size.width, lcBar.frame.size.height)];
    lblPrice.backgroundColor = [UIColor clearColor];
    lblPrice.textAlignment = UITextAlignmentRight;
    lblPrice.font = [UIFont boldSystemFontOfSize:15.0];
    lblPrice.textColor = [UIColor whiteColor];
    lblPrice.text = @"$2.99  ";
    
    [self.view addSubview:lcBar];
    [lcBar addSubview:lblMsg];
    [lcBar addSubview:lblPrice];
    
    [lcBar release];
    [lblMsg release];
    [lblPrice release];
#if 0
    /* Add menu to purhcase the full version or Full Fx pack or Sub Fx pack or Single filter */
    PopupMenu *menu = [[PopupMenu alloc]initWithFrame:CGRectMake(0, 0, 100, 150) style:UITableViewStylePlain delegate:self];
    [menu reloadData];
    [menu showPopupIn:_activityView at:CGPointMake(_activityView.center.x-_activityView.frame.origin.x, _activityView.center.y-_activityView.frame.origin.y)];
#else
    //SNPopupView *sp = [[SNPopupView alloc]initWithString:@"Maddaga Dengay!!!. Fuck off ass hole"];
    
    //[sp showAtPoint:CGPointMake(_activityView.center.x-_activityView.frame.origin.x, _activityView.center.y-_activityView.frame.origin.y) inView:_activityView];
    //[sp presentModalAtPoint:CGPointMake(_activityView.center.x-_activityView.frame.origin.x, _activityView.center.y-_activityView.frame.origin.y) inView:_activityView];
    if(nil != _lockedMenu)
    {
        [_lockedMenu dismissSNPopup];
        _lockedMenu = nil;
    }
    
    _lockedMenu = [[PopupMenu alloc]initWithFrame:CGRectMake(0, 0, 100, 150) style:UITableViewStylePlain delegate:self];
    [_lockedMenu reloadData];
    _lockedMenu.userInteractionEnabled = YES;
    _activityView.userInteractionEnabled = YES;
    [_lockedMenu showSNPopupIn:_activityView at:CGPointMake(_activityView.center.x-_activityView.frame.origin.x, _activityView.center.y-_activityView.frame.origin.y)];
    [_lockedMenu release];

#endif
}

-(void)removeLockedContentBarAndMenu
{
    if(nil != _lockedMenu)
    {
        [_lockedMenu dismissSNPopup];
        _lockedMenu = nil;
    }
    
    UIToolbar *effectBar = (UIToolbar*)[self.view viewWithTag:tag_lockedcontenttoolbar];
    if(nil != effectBar)
    {
        
        [effectBar removeFromSuperview];
        return;
    }
    
}

-(void)handleFilterSelection:(NSTimer*)timer
{
    _curGrpId = [[timer.userInfo objectForKey:@"groupid"]integerValue];
    _curFilter = [[timer.userInfo objectForKey:@"filter"]integerValue];
    
    switch(_curGrpId)
    {
#if MIRRORSET_SUPPORT
        case GROUP_STATIC_FILTER_MIRROR:
        {
            [self addMirror:_curFilter];
            break;
        }
#endif
        case GROUP_STATIC_FILTER_BOKEH:
        case GROUP_STATIC_FILTER_GRUNGE:
#if NOISESET_SUPPORT
        case GROUP_STATIC_FILTER_NOISE:
#endif
        case GROUP_STATIC_FILTER_SPACE:
        case GROUP_STATIC_FILTER_TEXTURE:
        case GROUP_STATIC_GPU_FILTER_VINTAGE:
        case GROUP_STATIC_GPU_FILTER_TONE:
        case GROUP_STATIC_GPU_FILTER_COLOR:
        case GROUP_STATIC_GPU_FILTER_CARTOON:
        case GROUP_STATIC_GPU_FILTER_SKETCH:
        {
            [self addStaticFilterOfGroup:_curGrpId atIndex:_curFilter withAlpha:1.0];
            break;
        }
        default:
        {
            NSLog(@"Filter is not supported");
            break;
        }
    }

#if MIRRORSET_SUPPORT
    /* We don't need effects toolbar in mirror mode */
    if(_curGrpId != GROUP_STATIC_FILTER_MIRROR)
#endif
    {
        if([StaticFilterMapping isFilterLockedOfGroup:_curGrpId atIndex:_curFilter])
        {
            [self hideActivity];
#if PHOTOEFFECTS_FLURRY_SUPPORT
            NSDictionary *filterParams =
            [NSDictionary dictionaryWithObjectsAndKeys:
             [StaticFilterMapping nameOfTheGroup:_curGrpId], @"Group",
             [StaticFilterMapping nameOfFilterInGroup:_curGrpId atIndex:_curFilter], @"Filter",
             nil];
            
            [Flurry logEvent:@"LockedStaticFilter selection frequency" withParameters:filterParams];
#endif
//#if PHOTOEFFECTS_INAPP_SUPPORT
//            [[InAppPurchaseManager Instance] puchaseProductWithId:[StaticFilterMapping productIdForGroup:_curGrpId]];
//#endif
            [self addLockedContentBarAndMenu];
            //return;
        }
        else
        {
#if PHOTOEFFECTS_FLURRY_SUPPORT
            NSDictionary *filterParams =
            [NSDictionary dictionaryWithObjectsAndKeys:
             [StaticFilterMapping nameOfTheGroup:_curGrpId], @"Group",
             [StaticFilterMapping nameOfFilterInGroup:_curGrpId atIndex:_curFilter], @"Filter",
             nil];
            [Flurry logEvent:@"StaticFilter selection frequency" withParameters:filterParams];
#endif
            [self removeLockedContentBarAndMenu];
            [self addEffectToolBar];
            
            TimeoutView *tv = [[TimeoutView alloc]initWithFrame:CGRectMake(0,0,full_screen.size.width-30,40.0)];
            tv.timeout = 5.0;
            tv.text = @"Click on merge to apply this effect";
            [tv showInView:_activityView];
            [tv release];
            
            [[OT_AdControl sharedInstance]bringBannerAdToFrontInSuperView:self.view];
        }
        
    }
    
    [self hideActivity];

}

- (void)filterDidSelectedInGroup:(NSInteger)grpId atIndex:(NSInteger)index
{
    [self.view bringSubviewToFront:_activityView];
    _activityView.alpha = 1.0;
    _activityView.image = nil;
    
    UIToolbar *effectBar = (UIToolbar*)[self.view viewWithTag:tag_effecttoolbar];
    if(nil != effectBar)
    {
        UISlider *strength = (UISlider*) [effectBar viewWithTag:tag_strengthslider];
        if(nil != strength)
        {
            strength.value = 1.0;
        }
    }

    [self showActivityWithMessage:@"Rendering"];

    NSDictionary *selection = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:grpId],@"groupid",[NSNumber numberWithInt:index],@"filter", nil];
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(handleFilterSelection:) userInfo:selection repeats:NO];
    //[self scheduleActivityIndicatorWithMessage:@"Applying"];
    //NSLog(@"filterDidSelectedInGroup:Filter at Index %d selected in group %d",index,grpId);
    
    
    return;
}

- (NSString*)nameOfTheFilterInGroup:(NSInteger)grpId atIndex:(NSInteger)index
{
    return [StaticFilterMapping nameOfFilterInGroup:grpId atIndex:index];
}

- (int)numberOfGroupsSupported
{
    return [StaticFilterMapping staticFilterGroupCount];
}

- (NSString*)getNameOfTheGroup:(int)grpId
{
    return [StaticFilterMapping nameOfTheGroup:grpId];
}


- (int)filterCountFor:(NSInteger)groupId
{
    return [StaticFilterMapping filterCountInGroup:groupId];
}

- (UIImage*)filterImageForGroup:(NSInteger)groupId atIndex:(NSInteger)index
{
    if(self._smallImage == nil)
    {
#if PHOTOEFFECTS_LIVEIMAGE_FOR_FILTERS
        float scale = 200.0/_leftGpuImage.frame.size.width;
        
        /* Get the scaled image */
        self._smallImage = [self getOutputImageFromView:_leftGpuImage ofScale:scale];
#else
        if(UIUserInterfaceIdiomPad == UI_USER_INTERFACE_IDIOM())
        {
            self._smallImage = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"sample_ipad" ofType:@"png"]];
        }
        else
        {
            self._smallImage = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"sample_iphone" ofType:@"png"]];
        }
#endif
        
        /* Get the output */
        
        //float scale = 100.0/320.0;
        //self._smallImage = [self getOutputImageOfScale:scale];
    }
    
    /* Apply the effect on the scaled image */
    UIImage *filteredImage =[self applyStaticFilterOfGroup:groupId atIndex:index onImage:self._smallImage withAlpha:1.0];

#if PHOTOEFFECTS_MIRROR_SUPPORT
    UIImage *output = [self applyMirrorOfType:_eCurMirror onImage:filteredImage];
#else
    UIImage *output = filteredImage;
#endif
    /* return the output image */
    //NSLog(@"Image size is %f,%f",self._smallImage.size.width,self._smallImage.size.height);
    return output;
}

-(BOOL)isContentLockedOfGrpId:(int)grpId atIndex:(int)index
{
    return [StaticFilterMapping isFilterLockedOfGroup:grpId atIndex:index];
}

-(UIImage*)getImageForGroup:(int)index
{
    UIImage *img = [UIImage imageNamed:@"TexturePack.png"];
    if(index == GROUP_STATIC_FILTER_GRUNGE)
    {
        img = [UIImage imageNamed:@"GrungePack.png"];
    }
    else if(index == GROUP_STATIC_FILTER_SPACE)
    {
        img = [UIImage imageNamed:@"SpacePack.png"];
    }
    else if(index == GROUP_STATIC_FILTER_BOKEH)
    {
        img = [UIImage imageNamed:@"BokehPack.png"];
    }
    
    return img;
}

-(void)groupExpandedWithId:(int)grpId
{
#if MIRRORSET_SUPPORT
    if(grpId == GROUP_STATIC_FILTER_MIRROR)
    {
        _activityView.image = nil;
        [self exitEffectToolBar:nil];
        _leftGpuImage.image = self._inputImage;
        _rightGpuImage.image = self._inputImage;
    }
#endif    
}

-(void)dismissModalControllerWithFadeoutAnimation:(UIViewController*)vc
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromRight;
    
    [self.view.window.layer addAnimation:transition forKey:nil];
    
    [vc dismissModalViewControllerAnimated:NO];
}
/*
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
}*/
-(void)exitEditor:(id)sender
{
#if PHOTOEFFECTS_CONFORMATION_ONEXIT
    UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"Discard Changes" message:@"You will loose all the changes that you have done so far, would you like to continue?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"Cancel", nil];
    av.tag = tag_discardchangesalert;
    [av show];
    [av release];
#else
    [self unregisterForNotifications];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_donewithphotoeffectseditor  object:_leftGpuImage.image];
    
    [self dismissModalControllerWithFadeoutAnimation:self];
#endif
    return;
}

#if PHOTOEFFECTS_SHARE_SUPPORT
-(void)showShareOptions:(id)sender
{
    ShareView *sv = [[ShareView alloc]initWithFrame:CGRectMake(0, 0, 180, 120)];
    sv.backgroundColor = SHARE_OPTIONS_COLOR;
    _shareTipView = [[CMPopTipView alloc]initWithCustomView:sv];
    _shareTipView.dismissTapAnywhere = YES;
    _shareTipView.borderWidth = 0.0f;
    UIView *targetView = (UIView *)[sender performSelector:@selector(view)];
    
    [_shareTipView presentPointingAtView:targetView inView:self.view animated:YES];
    [sv release];
}
#endif
-(void)exitEffectToolBar:(id)sender
{
    UIToolbar *camBar = (UIToolbar*)[self.view viewWithTag:tag_cameratoolbar];
    if(nil != camBar)
    {
        camBar.hidden = NO;
    }
    
    UIToolbar *effectBar = (UIToolbar*)[self.view viewWithTag:tag_effecttoolbar];
    if(nil != effectBar)
    {
        [effectBar removeFromSuperview];
        
        if(_undoIndex > 0)
        {
            _undoButton.enabled = YES;
        }
        
        if(_maxIndex > _undoIndex)
        {
            _redoButton.enabled = YES;
        }
        _activityView.image = nil;
        _activityView.alpha = 1.0;
        return;
    }
    
    return;
}

-(void)finishMergingCurrentEffectLayer:(NSTimer*)timer
{
    float newAlpha = [[timer.userInfo objectForKey:@"key_updatedtrengthvalue"]floatValue];
    UIImage *imageWithEffect = [timer.userInfo objectForKey:@"image"];
    
    [self exitEffectToolBar:nil];
#if 0
    //_leftGpuImage.image = [self addStaticFilterOfGroup:_curGrpId atIndex:_curFilter withAlpha:newAlpha];
#else
    _leftGpuImage.image = [_leftGpuImage.image blendOn:_leftGpuImage.image from:imageWithEffect inblendmode:kCGBlendModeNormal withAlpha:newAlpha];
#endif
    [imageWithEffect release];
    
#if PHOTOEFFECTS_MIRROR_SUPPORT
    _rightGpuImage.image = _leftGpuImage.image;
#endif
    
    self._inputImage = _leftGpuImage.image;
    
    /* we exited effects toolbar, so set it to nil, it will be initialized when user
     applies next effect */
    //_activityView.image = nil;
    
    /* First delete any redo images */
    [self deleteUndoImagesFrom:_undoIndex+1];
    
    /* Increment undo index */
    _undoIndex = _undoIndex + 1;
    _maxIndex  = _undoIndex;
    
    /* Store undo image */
    [self saveUndoImage:self._inputImage forUndoIndex:_undoIndex];
    
    /* disable redo button */
    _undoButton.enabled = YES;
    _redoButton.enabled = NO;
    _activityView.image = nil;
    _activityView.alpha = 1.0;

    [self hideActivity];
    
#if PHOTOEFFECTS_LIVEIMAGE_FOR_FILTERS
    float scale = 200.0/_leftGpuImage.frame.size.width;
    self._smallImage = [self getOutputImageOfScale:scale];
#endif
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_updateGroupImages object:nil];
    
    [[OT_AdControl sharedInstance]bringBannerAdToFrontInSuperView:self.view];
}

-(void)mergeCurrentEffectLayer:(id)sender
{
    //NSDictionary *info = [NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:_activityView.alpha] forKey:@"key_updatedtrengthvalue"];
    NSDictionary *info = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[NSNumber numberWithFloat:_activityView.alpha],[_activityView.image retain], nil] forKeys:[NSArray arrayWithObjects:@"key_updatedtrengthvalue", @"image",nil]];
    
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(finishMergingCurrentEffectLayer:) userInfo:info repeats:NO];

    _activityView.image = nil;
    _activityView.alpha = 1.0;

    [self showActivityWithMessage:@"Merging"];
}

-(void)updateEffectStrength:(UISlider*)strength
{
    _activityView.alpha = strength.value;
}

-(void)addEffectToolBar
{
    UIToolbar *effectBar = (UIToolbar*)[self.view viewWithTag:tag_effecttoolbar];
    if(nil != effectBar)
    {
        return;
    }
    
    UIToolbar *camBar = (UIToolbar*)[self.view viewWithTag:tag_cameratoolbar];
    if(nil != camBar)
    {
        camBar.hidden = YES;
    }
    
    effectBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, full_screen.size.height-scrollbar_height-toolbar_height+toolbar_sizeoffset, full_screen.size.width, toolbar_height-toolbar_sizeoffset)];
    effectBar.barStyle = UIBarStyleBlackOpaque;
    effectBar.tag = tag_effecttoolbar;

    UISlider *strengthSlider = [CustomUI allocateCustomSlider:CGRectMake(0, 0, full_screen.size.width-130.0, toolbar_height-4)];
    strengthSlider.maximumValue = 1.0;
    strengthSlider.minimumValue = 0.0;
    strengthSlider.value        = 1.0;
    strengthSlider.continuous   = YES;
    strengthSlider.tag = tag_strengthslider;
    [strengthSlider addTarget:self action:@selector(updateEffectStrength:) forControlEvents:UIControlEventValueChanged];
    
    UIBarButtonItem *strength = [[UIBarButtonItem alloc]initWithCustomView:strengthSlider];
    UIBarButtonItem *flex1BarButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *cancel = [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(exitEffectToolBar:)];
    UIBarButtonItem *merge = [[UIBarButtonItem alloc]initWithTitle:@"Merge" style:UIBarButtonItemStyleBordered target:self action:@selector(mergeCurrentEffectLayer:)];
    
    NSArray *itms = [NSArray arrayWithObjects:cancel,flex1BarButton,strength,flex1BarButton,merge, nil];
    [effectBar setItems:itms];
    
    [self.view addSubview:effectBar];
    [effectBar release];
    [strength release];
    [flex1BarButton release];
    [cancel release];
    [merge release];
    [strengthSlider release];
    
    _undoButton.enabled = NO;
    _redoButton.enabled = NO;
}

-(void)finishUndoPreviousFilter:(id)sender
{
    if(_undoIndex == 0)
    {
        return;
    }
    
    _undoIndex = _undoIndex - 1;
    _redoButton.enabled = YES;
    
    /* Now load the images */
    self._inputImage = [self imageForUndoIndex:_undoIndex];
    _leftGpuImage.image = self._inputImage;
#if PHOTOEFFECTS_MIRROR_SUPPORT
    _rightGpuImage.image = self._inputImage;
#endif
    
    self._smallImage = nil;
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_updateGroupImages object:nil];
    
    if(_undoIndex == 0)
    {
        NSLog(@"Image Orientation is %d",self._inputImage.imageOrientation);
        _undoButton.enabled = NO;
    }
    else{
        _undoButton.enabled = YES;
    }
    
    [self hideActivity];
}

-(void)undoPreviousFilter:(id)sender
{
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(finishUndoPreviousFilter:) userInfo:nil repeats:NO];
    _undoButton.enabled = NO;

    [self showActivityWithMessage:@"Undoing"];

    return;
}

-(void)fininshRedoPreviousFilter:(id)sender
{
    if(_undoIndex == _maxIndex)
    {
        NSLog(@"redoPreviousFilter: Nothing is available to redo");
        return;
    }
    
    _undoIndex = _undoIndex + 1;
    _undoButton.enabled = YES;
    
    /* Now load the images */
    self._inputImage = [self imageForUndoIndex:_undoIndex];
    _leftGpuImage.image = self._inputImage;
#if PHOTOEFFECTS_MIRROR_SUPPORT
    _rightGpuImage.image = self._inputImage;
#endif
    self._smallImage = nil;
    [[NSNotificationCenter defaultCenter]postNotificationName:notification_updateGroupImages object:nil];
    
    if(_undoIndex == _maxIndex)
    {
        _redoButton.enabled = NO;
    }
    else
    {
        _redoButton.enabled = YES;
    }
    
#if 0
    [Utility removeActivityIndicatorFrom:_activityView];
#else
    [self hideActivity];
#endif
}

-(void)redoPreviousFilter:(id)sender
{
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(fininshRedoPreviousFilter:) userInfo:nil repeats:NO];
    _redoButton.enabled = NO;

    [self showActivityWithMessage:@"Redoing"];
}

#if PHOTOEFFECTS_UPGRADES_SUPPORT
-(void)showInApps:(id)sender
{
    UpgradeOptions *options = [[UpgradeOptions alloc]initWithFrame:CGRectMake(100.0, 100.0, 300.0, 190.0)];
    //[self.view addSubview:options];
    CMPopTipView *inappsPop = [[CMPopTipView alloc]initWithCustomView:options];
    //[[KGModal sharedInstance] showWithContentView:options andAnimated:YES];
    inappsPop.dismissTapAnywhere = YES;
    inappsPop.borderWidth = 0.0f;
    UIView *targetView = (UIView *)[sender performSelector:@selector(view)];
    
    [inappsPop presentPointingAtView:targetView inView:self.view animated:YES];
    
    [options release];
}
#endif
-(void)addControls
{
    self.view.backgroundColor = [UIColor blackColor];
    
    [self showMirrorOptions];
    
    /* First add toolbar */
    UIToolbar *toolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, full_screen.size.height-scrollbar_height-toolbar_height+toolbar_sizeoffset, full_screen.size.width, toolbar_height-toolbar_sizeoffset)];
    NSMutableArray *toolbarItems = [[NSMutableArray alloc]initWithCapacity:2];
    toolbar.barStyle = UIBarStyleBlackTranslucent;
    toolbar.tag = tag_cameratoolbar;
    
    UIBarButtonItem *back = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(exitEditor:)];
    [toolbarItems addObject:back];
    
#if PHOTOEFFECTS_INAPP_SUPPORT
    UIBarButtonItem *inAppButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"money.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(showInApps:)];
    [toolbarItems addObject:inAppButton];
#endif
    
    UIBarButtonItem *flex1BarButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolbarItems addObject:flex1BarButton];
    

    _undoButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"undo.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(undoPreviousFilter:)];
    [toolbarItems addObject:_undoButton];
    
    _redoButton = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"redo.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(redoPreviousFilter:)];
    [toolbarItems addObject:_redoButton];
    _redoButton.enabled = NO;
    _undoButton.enabled = NO;
                              
#if PHOTOEFFECTS_SHARE_SUPPORT
    UIBarButtonItem *share = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(showShareOptions:)];
    share.style = UIBarButtonItemStyleBordered;
    [toolbarItems addObject:share];
#endif
    
    //NSArray *itms = [NSArray arrayWithObjects:album,cam,flex1BarButton,_undoButton,_redoButton,share, nil];
    [toolbar setItems:toolbarItems];
     
    [self.view addSubview:toolbar];
    [toolbar release];
#if PHOTOEFFECTS_INAPP_SUPPORT
    [inAppButton release];
#endif
    [back release];
#if PHOTOEFFECTS_SHARE_SUPPORT
    [share release];
#endif
    [flex1BarButton release];
    [toolbarItems release];
    [_undoButton release];
    [_redoButton release];
}

#if PHOTOEFFECTS_SHARE_SUPPORT
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
	/* Dismiss the modelview controller */
	[controller dismissModalViewControllerAnimated:YES];
	
	switch(result)
	{
		case MFMailComposeResultSent:
		{
			UIAlertView *pickerAlert;
			
			pickerAlert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Successfully Sent the email!!!" delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"OK"),nil];
			
			/* Show the alert */
			[pickerAlert show];
			
			/* Release the alert */
			[pickerAlert release];
            
            [Appirater userDidSignificantEvent:NO];
#if PHOTOEFFECTS_FLURRY_SUPPORT
            NSDictionary *status = [NSDictionary dictionaryWithObject:@"Success" forKey:@"Upload Status"];
            [Flurry logEvent:@"Email Uploads" withParameters:status];
#endif
            
			break;
		}
		case MFMailComposeResultFailed:
		{
			UIAlertView *pickerAlert;
            
			pickerAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"EMAIL",@"Email") message:[error localizedDescription] delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"OK"),nil];
			
			/* Show the alert */
			[pickerAlert show];
			
			/* Release the alert */
			[pickerAlert release];
#if PHOTOEFFECTS_FLURRY_SUPPORT
            NSDictionary *status = [NSDictionary dictionaryWithObject:@"Failed" forKey:@"Upload Status"];
            [Flurry logEvent:@"Email Uploads" withParameters:status];
#endif
			break;
		}
		default:
		{
			break;
		}
	}
	
	return;
}

-(void)uploadToEmail
{
    NSAutoreleasePool *localPool     = [[NSAutoreleasePool alloc] init];
    
    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
    if (mailClass != nil)
    {
        /* We must always check whether the current device is configured for sending emails */
        if ([mailClass canSendMail])
        {
            NSString *appUrl = applicationUrl;
            NSString *emailBody = [NSString stringWithFormat:@"Made with iphone application - %@. \n",appUrl];
            
            NSString *emailSubject = [NSString stringWithFormat:@"From %@ iphone application",appname];
            
            /* Compose the email */
            MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
            picker.mailComposeDelegate          = self;
            [picker setSubject:emailSubject];
            
            /* Set the model transition style */
            picker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
            
            /* Attach an image to the email */
            //[picker addAttachmentData:UIImagePNGRepresentation([sess.frame renderToImageOfSize:nvm.uploadSize])
            //                 mimeType:@"image/png" fileName:@"PicShells"];
            [picker addAttachmentData:UIImageJPEGRepresentation([self getOutputImage],1.0)
                             mimeType:@"image/jpeg" fileName:appname];
            
            /* Fill out the email body text */
            [picker setMessageBody:emailBody isHTML:YES];
            
            /* Present the email compose view to the user */
            [self presentModalViewController:picker animated:YES];
            
            /* Free the resources */
            [picker release];
        }
        else
        {
            UIAlertView *emailAlert;
            
            emailAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"EMAIL",@"Email") message:NSLocalizedString(@"NOEMAIL",@"Email is not configured for this device!!!") delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK",nil];
            
            emailAlert.tag = 11;
            
            /* Show the alert */
            [emailAlert show];
            
            /* Release the alert */
            [emailAlert release];
        }
        
        /* Free the mailclass object */
        [mailClass release];
    }
    
    [localPool release];
    
    return;
}

-(void) saveImageToInstagram:(UIImage *)pImage
{
    if(nil == pImage)
    {
        NSLog(@"Image is nil");
    }
    
    [Appirater userDidSignificantEvent:NO];
#if PHOTOEFFECTS_FLURRY_SUPPORT    
    NSDictionary *status = [NSDictionary dictionaryWithObject:@"Success" forKey:@"Upload Status"];
    [Flurry logEvent:@"Instagram Uploads" withParameters:status];
#endif
    /* First Save the Image to documents directory
     1. Generate the path to save the file*/
    NSString *pathToSave = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/captions1.ig"];
    
    /* 2. Save the file */
    [UIImageJPEGRepresentation(pImage, 1.0) writeToFile:pathToSave atomically:YES];
    
    /* Verify if the instagram app is installed */
    NSURL *instagramUrl = [NSURL URLWithString:@"instagram://app"];
    if([[UIApplication sharedApplication]canOpenURL:instagramUrl])
    {
        documentInteractionController = [[UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:pathToSave]]retain];
        documentInteractionController.UTI = @"com.instagram.photo";
        documentInteractionController.delegate = self;
        documentInteractionController.annotation = [NSDictionary dictionaryWithObject:@"#MirrorCamFx #InstapicFrames #PicCells #ColorSplurge #InstaSplash" forKey:@"InstagramCaption"];
        [documentInteractionController presentOpenInMenuFromRect:CGRectZero inView:self.view animated:YES];
    }
    else
    {
#if PHOTOEFFECTS_FLURRY_SUPPORT
        [Flurry logEvent:@"Instagram Uploads Without Installed"];
#endif
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Failed" message:@"Instagram is not installed in your device. You need to install Instagram application to share your image with Instagram. Would you like to download it now?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Download", nil];
        [alert show];
        [alert release];
    }
}

- (void) documentInteractionController: (UIDocumentInteractionController *) controller didEndSendingToApplication: (NSString *) application
{
    [documentInteractionController release];
    documentInteractionController = nil;
}

- (void)imageSavedToPhotosAlbum:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    UIAlertView *pickerAlert;
    
    if(nil == error)
    {
        pickerAlert = [[UIAlertView alloc] initWithTitle:@"Save To Album" message:@"Successfully Saved To Photo album!!!" delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"OK"),nil];
        
        /* Show the alert */
        [pickerAlert show];
        
        /* Release the alert */
        [pickerAlert release];
        
        [Appirater userDidSignificantEvent:NO];
#if PHOTOEFFECTS_FLURRY_SUPPORT
        NSDictionary *status = [NSDictionary dictionaryWithObject:@"Success" forKey:@"Upload Status"];
        [Flurry logEvent:@"Photo Album Uploads" withParameters:status];
#endif
    }
    else
    {
        pickerAlert = [[UIAlertView alloc] initWithTitle:@"Save To Album" message:error.localizedDescription delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"OK"),nil];
        
        /* Show the alert */
        [pickerAlert show];
        
        /* Release the alert */
        [pickerAlert release];
        
#if PHOTOEFFECTS_FLURRY_SUPPORT
        NSDictionary *status = [NSDictionary dictionaryWithObject:@"Failed" forKey:@"Upload Status"];
        [Flurry logEvent:@"Photo Album Uploads" withParameters:status];
#endif
    }
    return;
}

-(void)saveToAlbum
{
    /* Save the image to photo album */
    UIImageWriteToSavedPhotosAlbum([self getOutputImage], self, @selector(imageSavedToPhotosAlbum: didFinishSavingWithError: contextInfo:), nil);
    
    return;
}

-(void)handleShareSelection:(NSTimer*)timer
{
    eShareOptions eSelectedOption = [[timer.userInfo objectForKey:key_selectedshareoption]integerValue];
    
    [self hideActivity];
    
    switch(eSelectedOption)
    {
        case SHARE_OPTION_ALBUM:
        {
            [self saveToAlbum];
            break;
        }
        case SHARE_OPTION_EMAIL:
        {
            [self uploadToEmail];
            break;
        }
        case SHARE_OPTION_INSTAGRAM:
        {
            [self saveImageToInstagram:[self getOutputImage]];
            break;
        }
        case SHARE_OPTION_MORE:
        {
            SHKItem *photo = [SHKItem image:[self getOutputImage] title:@""];
            SHKShareMenu *shareMenu = [[SHKShareMenu alloc] initWithStyle:UITableViewStyleGrouped];
            shareMenu.item = photo;
            [[SHK currentHelper]setRootViewController:self];
            [[SHK currentHelper] showViewController:shareMenu];
            [shareMenu release];
            [Flurry logEvent:@"Sharekit selections"];
            break;
        }
        default:
        {
            break;
        }
    }
}
#endif

-(void)receiveNotification:(NSNotification*)notification
{
#if PHOTOEFFECTS_SHARE_SUPPORT
    if([notification.name isEqualToString:notification_shareoptionselected])
    {
        //eShareOptions eSelectedOption = [[notification.userInfo objectForKey:key_selectedshareoption]integerValue];
        
        [_shareTipView dismissAnimated:YES];
        [self.view bringSubviewToFront:_activityView];
        [self showActivityWithMessage:@"Generating"];

        
        /* schedule the handling of share option */
        [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(handleShareSelection:) userInfo:notification.userInfo repeats:NO];
        
        //NSLog(@"Selected Share Option is %d",eSelectedOption);
    }
    else if([notification.name isEqualToString:kInAppPurchaseManagerTransactionSucceededNotification])
#else
    if([notification.name isEqualToString:kInAppPurchaseManagerTransactionSucceededNotification])
#endif
    {
        [[NSNotificationCenter defaultCenter]postNotificationName:notification_updateGroupImages object:nil];
        
        /* also remove the locked menu if it is open */
        if(nil != _lockedMenu)
        {
            [_lockedMenu dismissSNPopup];
            _lockedMenu = nil;
        }
    }
}

-(void)unregisterForNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:nil
                                                  object:nil];
}

-(void)registerForNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receiveNotification:)
                                                 name:nil
                                               object:nil];
}




-(void)continueHiding:(NSTimer*)tmr
{
    UIView *touch = (UIView*)[self.view viewWithTag:TAG_ACTIVITYINDICATOR+1];
    if(nil != touch)
    {
        [Utility removeActivityIndicatorFrom:touch];
        [touch removeFromSuperview];
    }
}

-(void)hideActivity
{
    NSLog(@"hideActivity called");
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(continueHiding:) userInfo:nil repeats:NO];
}

-(void)showActivityWithMessage:(NSString*)msg
{
    //NSLog(@"showActivityWithMessage: %@",msg);
    [self continueHiding:nil];
    //NSLog(@"showActivityWithMessage: %@ called hideActivity",msg);
    
    TouchDetectView *touchBlockView = [[TouchDetectView alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    touchBlockView.tag = TAG_ACTIVITYINDICATOR + 1;
    touchBlockView.backgroundColor = [UIColor blackColor];
    touchBlockView.alpha = 0.7;
    touchBlockView.userInteractionEnabled = YES;
    [self.view addSubview:touchBlockView];
    [touchBlockView release];
    [Utility addActivityIndicatotTo:touchBlockView withMessage:msg];
}

-(void)updateActivityMessageTo:(NSString*)msg
{
    UIView *touch = (UIView*)[self.view viewWithTag:TAG_ACTIVITYINDICATOR+1];
    if(nil != touch)
    {
        [Utility updateActivityMessageInView:touch to:msg];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.view.userInteractionEnabled = YES;
    [self registerForNotifications];
    
    [self addControls];
    
    _leftGpuImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, PHOTOEFFECTS_IMAGEDISPLAYVIEW_WIDTH, PHOTOEFFECTS_IMAGEDISPLAYVIEW_HEIGHT)];
    _leftGpuImage.contentMode = PHOTOEFFECTS_CONTENT_MODE;
    _leftGpuImage.image = self._inputImage;
#if PHOTOEFFECTS_MIRROR_SUPPORT
    _rightGpuImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, PHOTOEFFECTS_IMAGEDISPLAYVIEW_WIDTHh, PHOTOEFFECTS_IMAGEDISPLAYVIEW_HEIGHT)];
    _rightGpuImage.contentMode = UIViewContentModeScaleAspectFill;
    _rightGpuImage.image = self._inputImage;
#endif
    _activityView = [[UIImageView alloc]initWithFrame:CGRectMake(0,camera_y_position,PHOTOEFFECTS_IMAGEDISPLAYVIEW_WIDTH,PHOTOEFFECTS_IMAGEDISPLAYVIEW_HEIGHT)];
    _activityView.contentMode = PHOTOEFFECTS_CONTENT_MODE;
    _activityView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_activityView];
    [_activityView release];
#if PHOTOEFFECTS_MIRROR_SUPPORT
    [self addMirror:_eCurMirror];
    
    TimeoutView *time = [[TimeoutView alloc]initWithFrame:CGRectMake(0,0,full_screen.size.width-30,40.0)];
    time.timeout = 5.0;
    time.text = @"Double tap to change the mirror lense";
    [time showInView:self.view];
    time.center = _activityView.center;
#else
    UIView *v = [self getNoMirrorWithImage:_leftGpuImage];
    [self.view addSubview:v];
    [v release];
    
    NSLog(@"ViewFinder Rect %f,%f,%f,%f",v.frame.origin.x,v.frame.origin.y,v.frame.size.width,v.frame.size.height);
#endif    
    
#if PHOTOEFFECTS_ADSUPPORT
    [[OT_AdControl sharedInstance]moveBannerAdTo:self.view];
    
    [[OT_AdControl sharedInstance]showInterstitialIn:self];
#endif
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
