//
//  goalBasedOfferWallController.h
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/3/12.
//
//

#import <UIKit/UIKit.h>
#import "TapjoyConnect.h"

@interface goalBasedOfferWallController : UIViewController

@end
