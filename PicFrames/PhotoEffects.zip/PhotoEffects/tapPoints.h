//
//  tapPoints.h
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/3/12.
//
//

#import <Foundation/Foundation.h>
#import "TapjoyConnect.h"
@interface tapPoints : NSObject

+(tapPoints*)Instance;
-(void)spendPoints:(int)points;
@property(nonatomic,readwrite)int curScore;
@end
