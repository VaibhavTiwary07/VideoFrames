//
//  tapPoints.m
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/3/12.
//
//

#import "tapPoints.h"

@interface tapPoints()
{
    int _curPoints;
}
@end
@implementation tapPoints
@synthesize curScore;

static tapPoints *tapPointsSingleton = nil;

-(void)spendPoints:(int)points
{
    self.curScore = _curPoints - points;
    [TapjoyConnect spendTapPoints:points];
}

-(int)curScore
{
    return _curPoints;
}

-(void)setCurScore:(int)cScore
{
    _curPoints = cScore;
    
    [[NSUserDefaults standardUserDefaults]setObject:[NSNumber numberWithInt:_curPoints] forKey:@"currenttappoints"];
}

-(void)getUpdatedPoints:(NSNotification*)notifyObj
{
    if(nil == notifyObj)
    {
        return;
    }
    
    NSNumber *tapPoints = notifyObj.object;
    self.curScore = [tapPoints intValue];
    
    NSLog(@"getUpdatedPoints: %d",self.curScore);
    
    return;
}

-(void)registerForNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPoints:)
												 name:TJC_TAP_POINTS_RESPONSE_NOTIFICATION
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPoints:)
												 name:TJC_SPEND_TAP_POINTS_RESPONSE_NOTIFICATION
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPoints:)
												 name:TJC_AWARD_TAP_POINTS_RESPONSE_NOTIFICATION
											   object:nil];
}

-(id)init
{
    self = [super init];
    if(self)
    {
        NSNumber *score = [[NSUserDefaults standardUserDefaults]objectForKey:@"currenttappoints"];
        if(nil == score)
        {
            [[NSUserDefaults standardUserDefaults]setObject:[NSNumber numberWithInt:0] forKey:@"currenttappoints"];
            _curPoints = 0;
        }
        else
        {
            _curPoints = [score integerValue];
        }
        
        [self registerForNotifications];
        [TapjoyConnect getTapPoints];
        
        return self;
    }
    
    return self;
}

+(tapPoints*)Instance
{
    @synchronized([tapPoints class])
	{
        if (tapPointsSingleton == nil)
		{
            [[self alloc] init]; // assignment not done here
        }
    }
	
    return tapPointsSingleton;
}


+(id)allocWithZone:(NSZone *)zone
{
    @synchronized([tapPoints class])
	{
        if (tapPointsSingleton == nil)
		{
            tapPointsSingleton = [super allocWithZone:zone];
            return tapPointsSingleton;  // assignment and return on first allocation
        }
    }
    return nil; //on subsequent allocation attempts return nil
}


-(void)dealloc
{
    [super dealloc];
}

-(id)copyWithZone:(NSZone *)zone
{
    return self;
}


-(id)retain
{
    return self;
}


-(unsigned)retainCount
{
    return UINT_MAX;  //denotes an object that cannot be release
}


-(oneway void)release
{
    //do nothing
}

-(id)autorelease
{
    return self;
}
@end
