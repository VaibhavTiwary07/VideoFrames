//
//  sgwController.h
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/10/12.
//
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class sgwController;

#define notification_sgwcontroller_updatepreview @"sgwcontroller_updatepreview"

@protocol sgwDelegate <NSObject>
-(int)numberOfItemsInSqwController:(sgwController*)sender;
-(NSString*)sgwController:(sgwController*)sender titleForTheItemAtIndex:(int)index;
-(UIImage*)sgwController:(sgwController*)sender imageForTheItemAtIndex:(int)index;
-(void)sgwController:(sgwController*)sender itemDidSelectAtIndex:(int)index;
-(BOOL)sgwController:(sgwController*)sender isItemLockedAtIndex:(int)index;
-(void)sgwControllerDidCancel:(sgwController*)sender;
-(void)sgwController:(sgwController*)sender didDoneSelectingItemAtIndex:(int)index;
-(UIImage*)previewImageForSgwController:(sgwController*)sender;
@optional
-(id)previewViewForSgwController:(sgwController*)sender;
@end

#define SGW_ITEM_SIZE        100.0
#define SGW_ITEM_BORDER_SIZE 5.0
#define SGW_FONT_SIZE        13.0

@interface sgwController : UIViewController

@property(nonatomic,assign)id <sgwDelegate> sgw_delegate;
@property(nonatomic,readwrite)int tag;
@property(nonatomic,assign)UIImageView *backgroundView;

-(id)initWithDelegate:(id)del currentItem:(int)item;
@end
