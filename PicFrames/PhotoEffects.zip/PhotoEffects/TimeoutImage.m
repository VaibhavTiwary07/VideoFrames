//
//  TimeoutView.m
//  MirroFx
//
//  Created by Vijaya kumar reddy Doddavala on 10/19/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import "TimeoutImage.h"


@implementation TimeoutImage
@synthesize cornerRadius;
@synthesize timeout;
@synthesize sColor;
@synthesize sOpacity;
@synthesize sRadius;
@synthesize sOffset;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.timeout = 2.0;
        
        self.backgroundColor = [UIColor  colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.5];
        self.cornerRadius = 10.0;
        self.sColor = [UIColor blackColor];
        self.sOpacity = 0.8;
        self.sRadius = 10.0;
        self.sOffset = CGSizeMake(1.0, 1.0);
        self.contentMode = UIViewContentModeCenter;
    }
    return self;
}

-(void)suside:(NSTimer*)timer
{
    [self removeFromSuperview];
}

-(void)showInView:(UIView*)view
{
    if(nil == view)
    {
        return;
    }
    
    self.center = CGPointMake(view.center.x-view.frame.origin.x, view.center.y-view.frame.origin.y);
    [view addSubview:self];
    
    self.layer.cornerRadius  = self.cornerRadius;
    self.layer.shadowColor   = self.sColor.CGColor;
    self.layer.shadowOpacity = self.sOpacity;
    self.layer.shadowRadius   = self.sRadius;
    self.layer.shadowOffset  = self.sOffset;
    self.layer.borderColor = [UIColor blackColor].CGColor;
    self.layer.borderWidth = 1.0;
    
    [self start];
}

-(void)start
{
    [NSTimer scheduledTimerWithTimeInterval:self.timeout+0.5 target:self selector:@selector(suside:) userInfo:self repeats:NO];
    [UIView animateWithDuration:self.timeout animations:^{
        self.alpha = 0.0;
        
    }];
}

-(void)dealloc
{
    [super dealloc];
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */



@end
