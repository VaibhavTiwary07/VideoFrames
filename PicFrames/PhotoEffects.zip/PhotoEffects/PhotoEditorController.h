//
//  PhotoEditorController.h
//  MirroFx
//
//  Created by Vijaya kumar reddy Doddavala on 10/15/12.
//  Copyright (c) 2012 Cell Phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotoEffects_Config.h"
#if PHOTOEFFECTS_GPUIMAGE_SUPPORT
#import "GPUImage.h"
#endif
#import "config.h"
#import "efScrollView.h"
#import "StaticFilterMapping.h"
#import "UIImage+texture.h"
#import "Utility.h"
#if PHOTOEFFECTS_SHARE_SUPPORT
#import "ShareView.h"
#import "SHKCustomShareMenu.h"
#endif
#import "CMPopTipView.h"
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import "CustomUI.h"
#if PHOTOEFFECTS_UPGRADES_SUPPORT
#import "UpgradeOptions.h"
#endif
#import "InAppPurchaseManager.h"
#import "TimeoutView.h"
#import "TimeoutImage.h"
#import "OT_AdContorl.h"
#import "TouchView.h"
#import "Appirater.h"
#if PHOTOEFFECTS_FLURRY_SUPPORT
#import "FlurryAnalytics.h"
#endif
#import "PhotoEffects.h"
#import "UIImage+GPU.h"
#import "PopupMenu.h"
#import "goalBasedOfferWallController.h"
#import "tapPoints.h"
#import "SNPopupView.h"

#define toolbar_sizeoffset 0.0

@interface PhotoEditorController : UIViewController <efsDelegate,efsGroupDelegate,MFMailComposeViewControllerDelegate,UIDocumentInteractionControllerDelegate,UIAlertViewDelegate,PopupMenuDelegate,UIAlertViewDelegate>

#if PHOTOEFFECTS_MIRROR_SUPPORT
-(id)initWithImage:(UIImage*)img andMirror:(eMirror)mirror;
#endif

-(id)initWithImage:(UIImage*)img;

@end
