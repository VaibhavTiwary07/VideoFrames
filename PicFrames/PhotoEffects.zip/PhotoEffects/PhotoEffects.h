//
//  PhotoEffects.h
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 11/22/12.
//
//

#ifndef Instapicframes_PhotoEffects_h
#define Instapicframes_PhotoEffects_h

#define notification_donewithphotoeffectseditor @"notification_donewithphotoeffectseditor"

#endif
