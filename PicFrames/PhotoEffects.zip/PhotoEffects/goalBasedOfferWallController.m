//
//  goalBasedOfferWallController.m
//  Instapicframes
//
//  Created by Vijaya kumar reddy Doddavala on 12/3/12.
//
//

#import "goalBasedOfferWallController.h"

@interface goalBasedOfferWallController ()

@end

@implementation goalBasedOfferWallController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    CGRect fs = [[UIScreen mainScreen]bounds];
	// Do any additional setup after loading the view.
    UIToolbar *tb = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, fs.size.width, 50)];
    
    tb.barStyle = UIBarStyleBlack;
    //self.navigationController.navigationBarHidden = NO;
    
    //UIView *ofv = [TapjoyConnect showOffers];
    //[self.view addSubview:ofv];
    //ofv.userInteractionEnabled = YES;
    
    
    //ofv.frame = CGRectMake(0, 0, fs.size.width, fs.size.height);
    
    [self.view addSubview:tb];
    [tb release];
    
    [TapjoyConnect showOffersWithViewController:self];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(offerwallClosed:)
                                                 name:TJC_VIEW_CLOSED_NOTIFICATION
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPoints:)
												 name:TJC_TAP_POINTS_RESPONSE_NOTIFICATION
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPoints:)
												 name:TJC_SPEND_TAP_POINTS_RESPONSE_NOTIFICATION
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPoints:)
												 name:TJC_AWARD_TAP_POINTS_RESPONSE_NOTIFICATION
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPointsError:)
												 name:TJC_TAP_POINTS_RESPONSE_NOTIFICATION_ERROR
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPointsError:)
												 name:TJC_SPEND_TAP_POINTS_RESPONSE_NOTIFICATION_ERROR
											   object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(getUpdatedPointsError:)
												 name:TJC_AWARD_TAP_POINTS_RESPONSE_NOTIFICATION_ERROR
											   object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(showEarnedCurrencyAlert:)
												 name:TJC_TAPPOINTS_EARNED_NOTIFICATION
											   object:nil];
    [TapjoyConnect getTapPoints];
}

- (void)getUpdatedPoints:(NSNotification*)notifyObj
{
	NSNumber *tapPoints = notifyObj.object;
	NSString *tapPointsStr = [NSString stringWithFormat:@"Tap Points: %d", [tapPoints intValue]];
	NSLog(@"%@", tapPointsStr);
}

- (void)showEarnedCurrencyAlert:(NSNotification*)notifyObj
{
	NSNumber *tapPointsEarned = notifyObj.object;
	int earnedNum = [tapPointsEarned intValue];
	
	NSLog(@"Currency earned: %d", earnedNum);
	
	// Pops up a UIAlert notifying the user that they have successfully earned some currency.
	// This is the default alert, so you may place a custom alert here if you choose to do so.
	[TapjoyConnect showDefaultEarnedCurrencyAlert];
	
	// This is a good place to remove this notification since it is undesirable to have a pop-up alert during gameplay.
	[[NSNotificationCenter defaultCenter] removeObserver:self name:TJC_TAPPOINTS_EARNED_NOTIFICATION object:nil];
}

- (void)getUpdatedPointsError:(NSNotification*)notifyObj
{
	NSLog(@"getUpdatedPointsError");
}

-(void)offerwallClosed:(NSNotification*)notifyObj
{
	NSLog(@"Offerwall closed");
    [self dismissModalViewControllerAnimated:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
