//
//  OT_LeadBoltOfferWall.h
//  animal_sounds
//
//  Created by Sunitha Gadigota on 5/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OT_Config.h"
#import "MBProgressHUD.h"

@interface OT_LeadBoltOfferWall : UIViewController <UIWebViewDelegate>

@end
