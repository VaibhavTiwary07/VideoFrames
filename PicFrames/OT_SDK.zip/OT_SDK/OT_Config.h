//
//  config.h
//  pullalerts
//
//  Created by Vijay Kumar Reddy Doddavala on 5/24/12.
//  Copyright (c) 2012 Out Thinking Private Limited. All rights reserved.
//

#ifndef ot_config_h
#define ot_config_h

#import "Config.h"

/* Fill the Application Id you can find it in itunes connect */
//#define iosAppId  iosAppId

/* Fill the  */
#define ot_config_url @"http://photoandvideoapps.com/News/soundboardapps.xml"

/* Default cache size */
#define ot_default_ad_cache_size 5

/* Lead Bolt Offer Wall URL */
//#define ot_lb_offerwall @"http://ad.leadboltads.net/show_app_wall?section_id=798710377"

/* Lead Bolt Offer Wall URL */
#define ot_lb_offerwall @"http://ad.leadboltads.net/show_app_wall?section_id=441389911"

/* MobClix App Id */
#define ot_mobclix_appid @"F0FD49C0-115F-4477-B92C-F592A036C33F"

/* Tapjoy App Id */
#define ot_tapjoy_appid  @"40a616d2-1fe7-41db-aa7a-5ac00c0d4531"


/* Tapjoy Secret Key */
#define ot_tapjoy_secretkey @"K7r3rYGvIsodGCwdpkeZ"


#define ot_revmob_appid @"4fdbfff539906f000c000038"

#endif
