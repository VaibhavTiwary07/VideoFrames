//
//  OT_Priv.h
//  Instacolor Splash
//
//  Created by Vijaya kumar reddy Doddavala on 7/25/12.
//  Copyright (c) 2012 motorola. All rights reserved.
//

#ifndef Instacolor_Splash_OT_Priv_h
#define Instacolor_Splash_OT_Priv_h



#endif
